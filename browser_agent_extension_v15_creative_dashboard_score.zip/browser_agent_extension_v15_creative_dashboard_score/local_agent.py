# -*- coding: utf-8 -*-
"""
TikTok GMV Max 广告管家本地端 v1.5
作用：接收 Chrome 插件发来的 TikTok GMV Max 页面快照/截图，保存到 snapshots 文件夹，
      导出干净 CSV，和上次数据对比，数据无变化时不重复发送，生成 chatgpt_message.txt。
      v1.3 新增素材强识别：自动生成保留/观察/关停/加预算/新品冷启动建议。
运行：python local_agent.py
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime
from pathlib import Path
import base64
import csv
import hashlib
import json
import re
import socket
import sys
import traceback

HOST = "127.0.0.1"
PORT = 8774
VERSION = "1.5.0"
ROOT = Path(__file__).parent / "snapshots"
ROOT.mkdir(exist_ok=True)
LOG_FILE = ROOT / "monitor_log.jsonl"
STATE_FILE = ROOT / "monitor_state.json"
CREATIVE_STATE_FILE = ROOT / "creative_monitor_state.json"

CAMPAIGN_FIELDS = [
    "index",
    "campaignName",
    "status",
    "planBudgetUSD",
    "dailyBudgetUSD",
    "costUSD",
    "costBaseBudgetUSD",
    "roiProtection",
    "suggestion",
    "scheduleTime",
    "targetROI",
    "netCostUSD",
    "skuOrders",
    "avgOrderCostUSD",
    "revenueUSD",
    "roi",
    "protectionBaseROI",
    "diagnosis",
    "source",
    "rawText",
    "selector",
]



CREATIVE_FIELDS = [
    "index",
    "creativeName",
    "workId",
    "account",
    "authType",
    "publishTime",
    "creativeType",
    "isValidVideo",
    "status",
    "spendUSD",
    "impressions",
    "clicks",
    "ctr",
    "orders",
    "revenueUSD",
    "roi",
    "cpaUSD",
    "views",
    "completionRate",
    "actionCN",
    "diagnosis",
    "reason",
    "recommendation",
    "source",
    "rawText",
    "selector",
]


def export_creative_csv(path: Path, items):
    if not items:
        return None
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CREATIVE_FIELDS)
        writer.writeheader()
        for item in items:
            row = {k: item.get(k, "") for k in CREATIVE_FIELDS}
            writer.writerow(row)
    return str(path)



def is_date_like(value):
    return bool(re.search(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}", safe_text(value)))


def infer_creative_type(item: dict):
    name = safe_text(item.get("creativeName"))
    work_id = safe_text(item.get("workId"))
    raw = safe_text(item.get("rawText"))
    text = f"{name} {work_id} {raw}"
    if re.search(r"商品\s*卡片|Product\s*card|查看数据", text, re.I):
        return "商品卡片"
    # v1.3：作品 ID 是正常字段，不再因为纯数字 ID 过滤整行。
    if not name.strip() and not work_id.strip():
        return "字段空白行"
    if re.search(r"广告计划名称|广告计划预算|商品\s*GMV\s*Max_", text, re.I):
        return "疑似计划表错读行"
    if re.search(r"^作品\s*ID$|^创意素材$|^TikTok\s*账号$", name.strip(), re.I):
        return "疑似表头行"
    return "视频素材"

def diagnose_creative_item(item: dict):
    c = dict(item or {})
    ctype = infer_creative_type(c)
    c["creativeType"] = ctype
    valid = (ctype == "视频素材") and bool(safe_text(c.get("creativeName")).strip())
    c["isValidVideo"] = "是" if valid else "否"

    spend = n(c.get("spendUSD"))
    clicks = n(c.get("clicks"))
    ctr = n(c.get("ctr"))
    orders = n(c.get("orders"))
    revenue = n(c.get("revenueUSD"))
    roi = n(c.get("roi"))
    views = n(c.get("views"))
    completion = n(c.get("completionRate"))

    if not valid:
        c["actionCN"] = "过滤"
        c["diagnosis"] = "不参与视频素材诊断"
        if ctype == "商品卡片":
            c["reason"] = "这是商品卡片/商品入口，不是视频创意素材。"
            c["recommendation"] = "单独放到商品卡片数据里看，不和视频素材混合判断。"
        else:
            c["reason"] = "该行字段疑似错位，例如作品 ID 被当成素材名、发布时间被当成状态。"
            c["recommendation"] = "过滤该行，避免误判点击、订单、ROI。"
        return c

    # 规则偏保守：低花费小样本先观察，不直接关。
    if orders >= 2 and roi >= 4:
        c["actionCN"] = "保留 + 复制重拍"
        c["diagnosis"] = "有效成交素材"
        c["reason"] = f"已有 {int(orders)} 单，ROI {roi:.2f}，具备继续放量和复刻价值。"
        c["recommendation"] = "保留当前素材；复制同结构重拍 2-3 条，重点复刻前3秒、展示角度、产品卖点。"
    elif orders >= 1 and roi >= 5:
        c["actionCN"] = "保留观察"
        c["diagnosis"] = "小样本高 ROI 素材"
        c["reason"] = f"已有成交且 ROI {roi:.2f} 较高，但订单样本还少。"
        c["recommendation"] = "继续小预算观察，订单达到 3-5 单后再决定复制重拍。"
    elif spend >= 5 and orders <= 0:
        c["actionCN"] = "暂停/换素材"
        c["diagnosis"] = "消耗无订单"
        c["reason"] = f"消耗已到 {spend:.2f} USD 但没有订单。"
        c["recommendation"] = "优先暂停；如果 CTR 高但无订单，检查商品页、价格、优惠；如果 CTR 低，换开头和封面。"
    elif spend >= 2 and orders <= 0 and clicks >= 10:
        c["actionCN"] = "优化落地/观察"
        c["diagnosis"] = "有点击无转化"
        c["reason"] = f"已有 {int(clicks)} 次点击但 0 单。"
        c["recommendation"] = "检查商品价格、优惠券、运费、SKU、评价；素材先不放量。"
    elif spend >= 1 and ctr > 0 and ctr < 1:
        c["actionCN"] = "换开头/封面"
        c["diagnosis"] = "点击率偏低"
        c["reason"] = f"CTR 约 {ctr:.2f}%，说明第一眼吸引力不足。"
        c["recommendation"] = "重做前3秒：直接展示手机壳上机效果、近景边框、镜头圈、强光泽卖点。"
    elif spend < 1:
        c["actionCN"] = "继续观察"
        c["diagnosis"] = "数据太少"
        c["reason"] = f"当前消耗仅 {spend:.2f} USD，样本不足。"
        c["recommendation"] = "继续观察，不要因为 0 单立即关；等消耗到 2-5 USD 再看点击和订单。"
    elif clicks <= 0 and spend >= 1:
        c["actionCN"] = "换素材入口"
        c["diagnosis"] = "有消耗无点击"
        c["reason"] = "有消耗但没有点击，素材吸引力弱或曝光人群不匹配。"
        c["recommendation"] = "换封面、开头钩子、字幕卖点，优先做真实上手/镜头保护近景。"
    else:
        c["actionCN"] = "继续观察"
        c["diagnosis"] = "暂无明显异常"
        c["reason"] = "当前数据没有达到关停或放量阈值。"
        c["recommendation"] = "继续观察下一轮变化，重点看订单是否增加、ROI 是否稳定。"

    return c


def build_creative_analysis(creative: dict):
    raw_items = creative.get("items") or []
    diagnosed = [diagnose_creative_item(x) for x in raw_items]
    valid = [x for x in diagnosed if x.get("isValidVideo") == "是"]
    product_cards = [x for x in diagnosed if x.get("creativeType") == "商品卡片"]
    abnormal = [x for x in diagnosed if x.get("creativeType") != "商品卡片" and x.get("isValidVideo") != "是"]

    keep = [x for x in valid if "保留" in safe_text(x.get("actionCN"))]
    remake = [x for x in valid if "复制重拍" in safe_text(x.get("actionCN"))]
    stop = [x for x in valid if re.search(r"暂停|换素材|换素材入口", safe_text(x.get("actionCN")))]
    observe = [x for x in valid if "观察" in safe_text(x.get("actionCN")) and x not in keep]
    low_ctr = [x for x in valid if "换开头" in safe_text(x.get("actionCN"))]

    def total(field):
        return round(sum(n(x.get(field)) for x in valid), 2)

    summary = {
        "rawRows": len(raw_items),
        "validVideoRows": len(valid),
        "productCardRows": len(product_cards),
        "abnormalRows": len(abnormal),
        "totalSpendUSD": total("spendUSD"),
        "totalRevenueUSD": total("revenueUSD"),
        "totalOrders": round(sum(n(x.get("orders")) for x in valid), 2),
        "overallROI": round(total("revenueUSD") / total("spendUSD"), 2) if total("spendUSD") > 0 else 0,
        "keepCount": len(keep),
        "remakeCount": len(remake),
        "observeCount": len(observe),
        "stopCount": len(stop),
        "lowCtrCount": len(low_ctr),
    }
    return {
        "version": VERSION,
        "summary": summary,
        "items": diagnosed,
        "validVideos": valid,
        "productCards": product_cards,
        "abnormalRows": abnormal,
        "groups": {"keep": keep, "remake": remake, "observe": observe, "stop": stop, "lowCtr": low_ctr},
    }




CREATIVE_SCORE_FIELDS = [
    "index", "grade", "score", "creativeName", "workId", "account", "status", "spendUSD", "clicks", "ctr",
    "orders", "revenueUSD", "roi", "completionRate", "actionCN", "scoreReason", "remakeDirection", "creativeType"
]


def grade_creative_item(item: dict):
    """v1.5 素材评分分级：S/A/B/C/D/E。"""
    x = dict(item or {})
    if x.get("isValidVideo") != "是":
        x.update({
            "grade": "E",
            "score": 0,
            "scoreReason": "非有效视频素材或字段异常，不参与评分。",
            "remakeDirection": "不重拍；先修正数据或过滤。",
        })
        return x

    spend = n(x.get("spendUSD"))
    clicks = n(x.get("clicks"))
    ctr = n(x.get("ctr"))
    orders = n(x.get("orders"))
    revenue = n(x.get("revenueUSD"))
    roi = n(x.get("roi"))
    completion = n(x.get("completionRate"))

    score = 45
    reasons = []
    # 订单和 ROI 权重最高。
    if orders >= 3:
        score += 25; reasons.append(f"订单 {orders:g} 单")
    elif orders >= 1:
        score += 15; reasons.append(f"已有 {orders:g} 单")
    else:
        reasons.append("暂未出单")

    if roi >= 8:
        score += 25; reasons.append(f"ROI {roi:.2f} 很高")
    elif roi >= 4:
        score += 18; reasons.append(f"ROI {roi:.2f} 达标")
    elif roi >= 2:
        score += 8; reasons.append(f"ROI {roi:.2f} 可观察")
    elif spend >= 2:
        score -= 12; reasons.append(f"ROI {roi:.2f} 偏低")

    if ctr >= 5:
        score += 10; reasons.append(f"CTR {ctr:.2f}% 吸引力强")
    elif ctr >= 2:
        score += 5; reasons.append(f"CTR {ctr:.2f}% 可接受")
    elif spend >= 1 and ctr > 0:
        score -= 8; reasons.append(f"CTR {ctr:.2f}% 偏低")

    if completion >= 20:
        score += 5; reasons.append(f"完播率 {completion:.2f}% 较好")
    elif spend >= 1 and completion > 0 and completion < 8:
        score -= 5; reasons.append(f"完播率 {completion:.2f}% 偏低")

    # 风险扣分。
    if spend >= 5 and orders <= 0:
        score = min(score, 25); reasons.append("消耗达到判断线但 0 单")
    elif spend >= 2 and clicks >= 10 and orders <= 0:
        score = min(score, 40); reasons.append("有点击无成交，需检查商品页/价格")
    elif spend < 1 and orders <= 0:
        score = min(score, 55); reasons.append("样本太小，先不下结论")

    score = max(0, min(100, int(round(score))))

    if score >= 85 and orders >= 2 and roi >= 5:
        grade = "S"
        action = "重点保留 + 复制重拍"
        direction = "保留原素材结构；同款脚本重拍 3 条：1条强化前1秒背面高光，1条强化镜头圈近景，1条强化侧边按键/边框细节。"
    elif score >= 70 and orders >= 1:
        grade = "A"
        action = "保留观察 + 复制备份"
        direction = "保留现有素材；复制重拍 1-2 条，重点优化前3秒钩子、封面和产品近景。"
    elif score >= 55:
        grade = "B"
        action = "继续观察 / 优化落地"
        direction = "先不放量；如果点击高无成交，检查价格、优惠、SKU、评价；如果点击低，换封面和开头。"
    elif score >= 35:
        grade = "C"
        action = "小样本继续观察"
        direction = "继续观察到 2-5 USD 消耗；不要立即重拍或停投。"
    else:
        grade = "D"
        action = "暂停 / 换素材"
        direction = "暂停或换开头；新素材要更快展示手机壳背面、镜头保护圈、边框质感和适配机型。"

    # 和原诊断动作合并：原诊断更保守/更强时保留原建议参考。
    x.update({
        "grade": grade,
        "score": score,
        "scoreReason": "；".join(reasons),
        "remakeDirection": direction,
        "actionCN": action,
    })
    return x


def build_creative_score(analysis: dict):
    diagnosed = analysis.get("items") or []
    scored = [grade_creative_item(x) for x in diagnosed]
    valid = [x for x in scored if x.get("isValidVideo") == "是"]
    grade_counts = {g: len([x for x in scored if x.get("grade") == g]) for g in ["S", "A", "B", "C", "D", "E"]}
    top = sorted([x for x in valid if x.get("grade") in ("S", "A")], key=lambda x: (n(x.get("score")), n(x.get("orders")), n(x.get("roi"))), reverse=True)
    watch = sorted([x for x in valid if x.get("grade") in ("B", "C")], key=lambda x: (n(x.get("score")), n(x.get("spendUSD"))), reverse=True)
    bad = sorted([x for x in valid if x.get("grade") == "D"], key=lambda x: (n(x.get("spendUSD")), -n(x.get("score"))), reverse=True)
    summary = analysis.get("summary") or {}
    return {
        "version": VERSION,
        "generatedAt": datetime.now().isoformat(),
        "summary": {
            **summary,
            "gradeCounts": grade_counts,
            "topCount": len(top),
            "watchCount": len(watch),
            "badCount": len(bad),
        },
        "items": scored,
        "groups": {"top": top, "watch": watch, "bad": bad},
    }


def export_creative_score_csv(path: Path, score_data: dict):
    items = score_data.get("items") or []
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CREATIVE_SCORE_FIELDS)
        writer.writeheader()
        for i, item in enumerate(items, 1):
            row = {k: item.get(k, "") for k in CREATIVE_SCORE_FIELDS}
            row["index"] = i
            writer.writerow(row)
    return str(path)


def export_creative_advice(path: Path, score_data: dict):
    groups = score_data.get("groups") or {}
    s = score_data.get("summary") or {}
    gc = s.get("gradeCounts") or {}
    lines = [
        "TikTok 素材 Dashboard + 评分分级 v1.5",
        "",
        "【素材总览】",
        f"有效视频素材：{s.get('validVideoRows', 0)}",
        f"总消耗：{s.get('totalSpendUSD', 0)} USD",
        f"总订单：{s.get('totalOrders', 0)}",
        f"总收入：{s.get('totalRevenueUSD', 0)} USD",
        f"整体 ROI：{s.get('overallROI', 0)}",
        f"分级：S {gc.get('S',0)}｜A {gc.get('A',0)}｜B {gc.get('B',0)}｜C {gc.get('C',0)}｜D {gc.get('D',0)}｜E {gc.get('E',0)}",
        "",
        "【S/A：重点保留或复制重拍】",
    ]
    def fmt(x):
        return f"- [{x.get('grade')}] {safe_text(x.get('creativeName'))[:80]}｜分数:{x.get('score')}｜订单:{x.get('orders')}｜ROI:{x.get('roi')}｜原因:{x.get('scoreReason')}｜重拍:{x.get('remakeDirection')}"
    arr = groups.get("top") or []
    lines.extend([fmt(x) for x in arr[:10]] or ["- 暂无"])
    lines.append("")
    lines.append("【B/C：继续观察】")
    arr = groups.get("watch") or []
    lines.extend([fmt(x) for x in arr[:10]] or ["- 暂无"])
    lines.append("")
    lines.append("【D：暂停/换素材】")
    arr = groups.get("bad") or []
    lines.extend([fmt(x) for x in arr[:10]] or ["- 暂无"])
    path.write_text("\n".join(lines), encoding="utf-8")
    return str(path)


def find_latest_creative_folder():
    folders = [x for x in ROOT.iterdir() if x.is_dir()]
    folders.sort(key=lambda x: x.name, reverse=True)
    for folder in folders:
        if (folder / "creative_score.json").exists() or (folder / "creative_diagnosis.json").exists() or (folder / "creative_items.json").exists():
            return folder
    return None


def generate_creative_dashboard_html():
    folder = find_latest_creative_folder()
    if not folder:
        return f"""<!doctype html><html><head><meta charset='utf-8'><title>素材 Dashboard v1.5</title></head><body style='font-family:Arial,Microsoft YaHei,sans-serif;padding:20px'><h1>素材 Dashboard v1.5</h1><p>暂无素材采集数据。先在插件里执行“刷新当前素材页并填入/发送”或开启素材定时监控。</p><p>本地地址：http://{HOST}:{PORT}/creative-dashboard</p></body></html>"""
    score = read_json(folder / "creative_score.json", default={}) or {}
    if not score:
        analysis = read_json(folder / "creative_diagnosis.json", default={}) or {}
        score = build_creative_score(analysis) if analysis else {}
    s = score.get("summary") or {}
    gc = s.get("gradeCounts") or {}
    groups = score.get("groups") or {}
    change = read_json(folder / "creative_change.json", default={}) or read_json(folder / "change.json", default={}) or {}
    events = change.get("importantEvents") or []

    def esc(v):
        return safe_text(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    def li_items(items):
        if not items:
            return "<li>暂无</li>"
        out = []
        for x in items[:12]:
            out.append(f"<li><b>[{esc(x.get('grade'))}] {esc(safe_text(x.get('creativeName'))[:90])}</b><br><span>分数 {esc(x.get('score'))}｜消耗 {esc(x.get('spendUSD'))} USD｜订单 {esc(x.get('orders'))}｜收入 {esc(x.get('revenueUSD'))} USD｜ROI {esc(x.get('roi'))}</span><br><span class='small'>{esc(x.get('scoreReason'))}</span><br><span class='small'>重拍方向：{esc(x.get('remakeDirection'))}</span></li>")
        return "".join(out)
    rows = []
    for x in sorted(score.get("items") or [], key=lambda z: (safe_text(z.get("grade")), -n(z.get("score"))))[:80]:
        rows.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            esc(x.get('grade')), esc(x.get('score')), esc(safe_text(x.get('creativeName'))[:80]), esc(x.get('spendUSD')), esc(x.get('orders')), esc(x.get('revenueUSD')), esc(x.get('roi')), esc(x.get('ctr')), esc(x.get('actionCN'))
        ))
    event_html = "".join(f"<li>{esc(e)}</li>" for e in events[:10]) or "<li>暂无重要变化</li>"
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>素材 Dashboard v1.5</title>
<style>
body{{font-family:Arial,'Microsoft YaHei',sans-serif;background:#f5f6f8;margin:0;padding:18px;color:#111}}
.card{{background:#fff;border:1px solid #ddd;border-radius:12px;padding:14px;margin:12px 0;box-shadow:0 1px 2px rgba(0,0,0,.03)}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.cols{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}}
.kpi{{background:#111;color:#fff;border-radius:12px;padding:14px}}.kpi b{{font-size:25px}}
table{{width:100%;border-collapse:collapse;background:#fff}}td,th{{border:1px solid #ddd;padding:8px;font-size:13px}}
.small{{color:#555;font-size:12px}}ul{{padding-left:20px}}li{{margin:8px 0}}.ok{{border-left:5px solid #159947}}.warn{{border-left:5px solid #e5a100}}.bad{{border-left:5px solid #cc3333}}
.badge{{display:inline-block;background:#111;color:#fff;border-radius:10px;padding:3px 8px;margin:3px}}
</style></head><body>
<h1>TikTok 素材 Dashboard + 评分分级 v1.5</h1>
<div class='small'>本地地址：http://{HOST}:{PORT}/creative-dashboard ｜ 最新素材文件夹：{esc(folder)}</div>
<div class='grid'>
<div class='kpi'>素材消耗<br><b>{esc(s.get('totalSpendUSD',0))}</b> USD</div>
<div class='kpi'>素材订单<br><b>{esc(s.get('totalOrders',0))}</b></div>
<div class='kpi'>素材收入<br><b>{esc(s.get('totalRevenueUSD',0))}</b> USD</div>
<div class='kpi'>整体 ROI<br><b>{esc(s.get('overallROI',0))}</b></div>
</div>
<div class='card'><h2>素材分级</h2><span class='badge'>S {gc.get('S',0)}</span><span class='badge'>A {gc.get('A',0)}</span><span class='badge'>B {gc.get('B',0)}</span><span class='badge'>C {gc.get('C',0)}</span><span class='badge'>D {gc.get('D',0)}</span><span class='badge'>E {gc.get('E',0)}</span><p>有效视频素材：{esc(s.get('validVideoRows',0))}｜商品卡片过滤：{esc(s.get('productCardRows',0))}｜异常过滤：{esc(s.get('abnormalRows',0))}</p><h3>重要变化/预警</h3><ul>{event_html}</ul></div>
<div class='cols'>
<div class='card ok'><h2>S/A 保留 + 重拍</h2><ul>{li_items(groups.get('top') or [])}</ul></div>
<div class='card warn'><h2>B/C 继续观察</h2><ul>{li_items(groups.get('watch') or [])}</ul></div>
<div class='card bad'><h2>D 暂停 / 换素材</h2><ul>{li_items(groups.get('bad') or [])}</ul></div>
</div>
<div class='card'><h2>全部素材评分表</h2><table><tr><th>等级</th><th>分数</th><th>素材</th><th>消耗</th><th>订单</th><th>收入</th><th>ROI</th><th>CTR</th><th>建议</th></tr>{''.join(rows)}</table></div>
</body></html>"""
    return html


def creative_key(item: dict):
    wid = safe_text(item.get("workId")).strip()
    if wid:
        return wid
    name = safe_text(item.get("creativeName")).strip()
    acct = safe_text(item.get("account")).strip()
    return f"{name}|{acct}" if name else ""


def creative_state_map(items):
    mp = {}
    for x in items or []:
        if x.get("isValidVideo") != "是":
            continue
        key = creative_key(x)
        if not key:
            continue
        mp[key] = {
            "creativeName": safe_text(x.get("creativeName")),
            "workId": safe_text(x.get("workId")),
            "account": safe_text(x.get("account")),
            "status": safe_text(x.get("status")),
            "spendUSD": n(x.get("spendUSD")),
            "clicks": n(x.get("clicks")),
            "ctr": n(x.get("ctr")),
            "orders": n(x.get("orders")),
            "revenueUSD": n(x.get("revenueUSD")),
            "roi": n(x.get("roi")),
            "completionRate": n(x.get("completionRate")),
            "actionCN": safe_text(x.get("actionCN")),
            "diagnosis": safe_text(x.get("diagnosis")),
        }
    return mp


def creative_fingerprint(summary: dict, items):
    canonical = {
        "summary": {
            "validVideoRows": summary.get("validVideoRows", 0),
            "totalSpendUSD": round(n(summary.get("totalSpendUSD")), 2),
            "totalRevenueUSD": round(n(summary.get("totalRevenueUSD")), 2),
            "totalOrders": round(n(summary.get("totalOrders")), 2),
            "overallROI": round(n(summary.get("overallROI")), 2),
        },
        "itemsByKey": creative_state_map(items),
    }
    raw = json.dumps(canonical, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest(), canonical


def compare_creative_with_previous(analysis: dict, meta: dict):
    summary = analysis.get("summary") or {}
    valid = analysis.get("validVideos") or []
    prev = read_json(CREATIVE_STATE_FILE, default={}) or {}
    fingerprint, canonical = creative_fingerprint(summary, valid)
    prev_fingerprint = prev.get("fingerprint")
    has_previous = bool(prev_fingerprint)
    changed = fingerprint != prev_fingerprint
    prev_summary = prev.get("summary") or {}
    prev_items = prev.get("itemsByKey") or {}
    cur_items = canonical["itemsByKey"]

    delta_spend = round(n(summary.get("totalSpendUSD")) - n(prev_summary.get("totalSpendUSD")), 2) if has_previous else 0
    delta_revenue = round(n(summary.get("totalRevenueUSD")) - n(prev_summary.get("totalRevenueUSD")), 2) if has_previous else 0
    delta_orders = round(n(summary.get("totalOrders")) - n(prev_summary.get("totalOrders")), 2) if has_previous else 0
    delta_roi = round(n(summary.get("overallROI")) - n(prev_summary.get("overallROI")), 2) if has_previous else 0

    per = []
    events = []
    for key, cur in cur_items.items():
        old = prev_items.get(key)
        display = cur.get("creativeName") or key
        if not old:
            per.append({"key": key, "creativeName": display, "change": "new_creative", "current": cur})
            if has_previous:
                events.append(f"新增素材：{display}")
            continue
        d_spend = round(n(cur.get("spendUSD")) - n(old.get("spendUSD")), 2)
        d_orders = round(n(cur.get("orders")) - n(old.get("orders")), 2)
        d_revenue = round(n(cur.get("revenueUSD")) - n(old.get("revenueUSD")), 2)
        d_clicks = round(n(cur.get("clicks")) - n(old.get("clicks")), 2)
        d_roi = round(n(cur.get("roi")) - n(old.get("roi")), 2)
        status_changed = cur.get("status") != old.get("status")
        if d_spend or d_orders or d_revenue or d_clicks or d_roi or status_changed:
            per.append({
                "key": key,
                "creativeName": display,
                "deltaSpendUSD": d_spend,
                "deltaOrders": d_orders,
                "deltaRevenueUSD": d_revenue,
                "deltaClicks": d_clicks,
                "deltaROI": d_roi,
                "oldStatus": old.get("status"),
                "newStatus": cur.get("status"),
                "current": cur,
            })
        if d_orders > 0:
            events.append(f"素材新增订单：{display} +{d_orders:g} 单，收入 +{d_revenue} USD，ROI {cur.get('roi')}")
        if d_spend >= 1 and d_orders <= 0:
            events.append(f"素材消耗增加但无新增订单：{display} 花费 +{d_spend} USD，订单 +0")
        if n(old.get("roi")) >= 2 and n(cur.get("roi")) < n(old.get("roi")) * 0.7 and d_spend > 0:
            events.append(f"素材 ROI 明显下降：{display} 从 {old.get('roi')} 降到 {cur.get('roi')}")
        if status_changed:
            events.append(f"素材状态变化：{display} {old.get('status')} → {cur.get('status')}")

    for key, old in prev_items.items():
        if key not in cur_items:
            per.append({"key": key, "creativeName": old.get("creativeName") or key, "change": "missing_in_current"})
            if has_previous:
                events.append(f"本次未读取到上次素材：{old.get('creativeName') or key}")

    no_duplicate = meta.get("noDuplicate", True) is not False
    force_send = bool(meta.get("forceSend"))
    send_only_important = bool(meta.get("sendOnlyImportant"))
    if force_send:
        should_send = True
        send_reason = "手动强制发送"
    elif not valid:
        should_send = True
        send_reason = "未提取到有效视频素材，可能页面未加载或表格未读全"
    elif not has_previous:
        should_send = True
        send_reason = "第一次素材采集，发送基准数据"
    elif no_duplicate and not changed:
        should_send = False
        send_reason = "素材数据和上次完全一致，已拦截重复发送"
    elif send_only_important and not events:
        should_send = False
        send_reason = "素材有轻微变化，但没有新增订单/ROI异常/消耗无单等重要变化"
    else:
        should_send = True
        send_reason = "检测到素材重要变化" if events else "检测到素材数据变化"

    change = {
        "mode": "creative_monitor",
        "has_previous": has_previous,
        "changed": changed,
        "fingerprint": fingerprint,
        "previousFingerprint": prev_fingerprint,
        "deltaSpendUSD": delta_spend,
        "deltaRevenueUSD": delta_revenue,
        "deltaOrders": delta_orders,
        "deltaROI": delta_roi,
        "perCreativeChanges": per[:80],
        "importantEvents": events[:40],
        "eventCount": len(events),
        "shouldSend": should_send,
        "sendReason": send_reason,
        "previousUpdatedAt": prev.get("updatedAt", ""),
    }
    new_state = {
        "version": VERSION,
        "updatedAt": datetime.now().isoformat(),
        "fingerprint": fingerprint,
        "summary": canonical["summary"],
        "itemsByKey": cur_items,
    }
    return change, new_state


def export_creative_diagnosis_csv(path: Path, analysis: dict):
    items = analysis.get("items") or []
    return export_creative_csv(path, items)


def build_creative_diagnosis_message(snapshot: dict, creative: dict, analysis: dict, folder: Path, meta: dict, creative_change: dict = None):
    recognized = creative.get("recognized") or {}
    headers = creative.get("headers") or []
    s = analysis.get("summary") or {}
    groups = analysis.get("groups") or {}
    def ok(name):
        return "正常" if recognized.get(name) else "异常/未识别"
    def line_item(it):
        return (
            f"- {safe_text(it.get('creativeName'))[:120]}｜作品ID:{it.get('workId','')}｜账号:{it.get('account','')}｜类型:{it.get('creativeType','')}｜状态:{it.get('status','')}"
            f"｜消耗:{it.get('spendUSD','')} USD｜点击:{it.get('clicks','')}｜CTR:{it.get('ctr','')}"
            f"｜订单:{it.get('orders','')}｜收入:{it.get('revenueUSD','')} USD｜ROI:{it.get('roi','')}"
            f"｜建议:{it.get('actionCN','')}｜原因:{it.get('reason','')}"
        )

    lines = []
    lines.append("【素材监控诊断版 v1.3】请帮我复核素材：保留、复制重拍、继续观察、暂停/换素材。")
    lines.append("")
    lines.append(f"采集时间：{snapshot.get('capturedAt','')}")
    lines.append(f"页面：{snapshot.get('url','')}")
    lines.append(f"标题：{snapshot.get('title','')}")
    if creative_change:
        lines.append(f"发送原因：{creative_change.get('sendReason','')}")
        lines.append("")
        lines.append("【相比上次素材变化】")
        if not creative_change.get("has_previous"):
            lines.append("第一次素材采集，暂无上次数据，用作后续监控基准。")
        else:
            lines.append(f"消耗变化：{creative_change.get('deltaSpendUSD',0)} USD")
            lines.append(f"订单变化：{creative_change.get('deltaOrders',0)}")
            lines.append(f"收入变化：{creative_change.get('deltaRevenueUSD',0)} USD")
            lines.append(f"整体 ROI 变化：{creative_change.get('deltaROI',0)}")
            if not creative_change.get("changed"):
                lines.append("结论：和上次素材采集完全一致，本次不需要重复分析。")
        lines.append("")
        lines.append("【素材重要变化/预警】")
        ev = creative_change.get("importantEvents") or []
        if ev:
            lines.extend(f"- {x}" for x in ev[:15])
        else:
            lines.append("- 暂无重要变化")
        lines.append("")
    lines.append(f"素材原始行数：{s.get('rawRows',0)}")
    lines.append(f"有效视频素材：{s.get('validVideoRows',0)}；商品卡片过滤：{s.get('productCardRows',0)}；错位/异常行过滤：{s.get('abnormalRows',0)}")
    lines.append("")
    lines.append("【字段识别】")
    lines.append(f"素材名称:{ok('creativeName')}｜作品ID:{ok('workId')}｜消耗:{ok('spendUSD')}｜点击:{ok('clicks')}｜CTR:{ok('ctr')}｜订单:{ok('orders')}｜收入:{ok('revenueUSD')}｜ROI:{ok('roi')}｜播放:{ok('views')}｜完播:{ok('completionRate')}")
    if headers:
        lines.append("表头：" + "｜".join([safe_text(x) for x in headers[:30]]))
    lines.append("")
    lines.append("【素材总览，只统计有效视频素材】")
    lines.append(f"总消耗：{s.get('totalSpendUSD',0)} USD")
    lines.append(f"总收入：{s.get('totalRevenueUSD',0)} USD")
    lines.append(f"总订单：{s.get('totalOrders',0)}")
    lines.append(f"整体 ROI：{s.get('overallROI',0)}")
    lines.append(f"保留/复盘：{s.get('keepCount',0)} 个；复制重拍：{s.get('remakeCount',0)} 个；继续观察：{s.get('observeCount',0)} 个；建议暂停/换素材：{s.get('stopCount',0)} 个")

    sections = [
        ("【建议保留 / 复制重拍素材】", groups.get("keep") or []),
        ("【继续观察素材】", groups.get("observe") or []),
        ("【建议暂停 / 换素材】", groups.get("stop") or []),
        ("【点击率偏低 / 换开头素材】", groups.get("lowCtr") or []),
    ]
    for title, arr in sections:
        lines.append("")
        lines.append(title)
        if not arr:
            lines.append("- 暂无")
        else:
            for it in arr[:10]:
                lines.append(line_item(it))

    if analysis.get("productCards"):
        lines.append("")
        lines.append("【已过滤商品卡片】")
        for it in analysis.get("productCards", [])[:5]:
            lines.append(line_item(it))
    if analysis.get("abnormalRows"):
        lines.append("")
        lines.append("【已过滤字段错位/异常行】")
        for it in analysis.get("abnormalRows", [])[:5]:
            lines.append(line_item(it))

    lines.append("")
    lines.append("请按照下面格式输出：")
    lines.append("1. 立即保留的素材")
    lines.append("2. 建议复制重拍的素材，以及重拍方向")
    lines.append("3. 继续观察的素材")
    lines.append("4. 建议暂停/换素材的素材")
    lines.append("5. 商品卡片/异常行是否过滤正确")
    lines.append("")
    lines.append(f"本地文件夹：{folder}")
    lines.append("备注：完整素材 CSV 在 creative_items.csv，诊断 CSV 在 creative_diagnosis.csv，截图在 screenshot.png，原始页面文字在 page_text.txt。")
    return "\n".join(lines)


def build_creative_import_message(snapshot: dict, creative: dict, folder: Path, meta: dict):
    # v1.3 起素材消息默认升级为诊断版，同时保留函数名以兼容旧调用。
    analysis = build_creative_analysis(creative)
    return build_creative_diagnosis_message(snapshot, creative, analysis, folder, meta)

def write_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path, default=None):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def safe_text(value):
    return "" if value is None else str(value)


def n(value, default=0.0):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except Exception:
        return default


def r2(value):
    return round(n(value), 2)


def export_campaign_csv(path: Path, campaigns):
    if not campaigns:
        return None
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CAMPAIGN_FIELDS)
        writer.writeheader()
        for item in campaigns:
            row = {k: item.get(k, "") for k in CAMPAIGN_FIELDS}
            writer.writerow(row)
    return str(path)


def campaign_key(c: dict, idx=0):
    name = safe_text(c.get("campaignName")).strip()
    if name:
        return name
    return f"index_{idx}"


def normalize_campaign(c: dict, idx=0):
    return {
        "key": campaign_key(c, idx),
        "campaignName": safe_text(c.get("campaignName")),
        "status": safe_text(c.get("status")),
        "dailyBudgetUSD": r2(c.get("dailyBudgetUSD")),
        "costUSD": r2(c.get("costUSD")),
        "skuOrders": int(n(c.get("skuOrders"))),
        "revenueUSD": r2(c.get("revenueUSD")),
        "roi": r2(c.get("roi")),
        "targetROI": r2(c.get("targetROI")),
    }


def campaigns_by_key(campaigns):
    return {normalize_campaign(c, i)["key"]: normalize_campaign(c, i) for i, c in enumerate(campaigns or [])}


def make_fingerprint(summary: dict, campaigns: list):
    data = {
        "summary": {
            "totalCampaigns": int(n(summary.get("totalCampaigns"))),
            "activeCount": int(n(summary.get("activeCount"))),
            "pausedCount": int(n(summary.get("pausedCount"))),
            "totalSpendUSD": r2(summary.get("totalSpendUSD")),
            "totalRevenueUSD": r2(summary.get("totalRevenueUSD")),
            "totalOrders": int(n(summary.get("totalOrders"))),
            "overallROI": r2(summary.get("overallROI")),
        },
        "campaigns": sorted([normalize_campaign(c, i) for i, c in enumerate(campaigns or [])], key=lambda x: x["key"]),
    }
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest(), data


def build_brief(summary: dict, campaigns: list):
    campaigns = campaigns or []
    total = summary.get("totalCampaigns", len(campaigns))
    spend = n(summary.get("totalSpendUSD"))
    revenue = n(summary.get("totalRevenueUSD"))
    orders = int(n(summary.get("totalOrders")))
    roi = n(summary.get("overallROI"))

    active = [c for c in campaigns if c.get("status") == "已生效"]
    paused = [c for c in campaigns if c.get("status") == "已暂停"]
    stop_candidates = [c for c in campaigns if n(c.get("costUSD")) >= 5 and (n(c.get("skuOrders")) <= 0 or n(c.get("roi")) < 1)]
    good_candidates = [c for c in campaigns if n(c.get("skuOrders")) >= 10 and n(c.get("roi")) >= 3]
    observing = [c for c in active if n(c.get("costUSD")) < 3]

    best = sorted(campaigns, key=lambda c: (n(c.get("revenueUSD")), n(c.get("skuOrders")), n(c.get("roi"))), reverse=True)[:5]
    worst = sorted([c for c in campaigns if n(c.get("costUSD")) > 0], key=lambda c: (n(c.get("roi")), -n(c.get("costUSD"))))[:5]

    return {
        "totalCampaigns": int(n(total)),
        "activeCount": len(active),
        "pausedCount": len(paused),
        "totalSpendUSD": round(spend, 2),
        "totalRevenueUSD": round(revenue, 2),
        "totalOrders": orders,
        "overallROI": round(roi, 2),
        "stopCandidateCount": len(stop_candidates),
        "goodCandidateCount": len(good_candidates),
        "observingCount": len(observing),
        "best": best,
        "worst": worst,
    }


def fmt_campaign(c):
    return (
        f"- {c.get('campaignName','')}｜状态:{c.get('status','')}｜日预算:{c.get('dailyBudgetUSD','')} USD"
        f"｜花费:{c.get('costUSD','')} USD｜订单:{c.get('skuOrders','')}"
        f"｜收入:{c.get('revenueUSD','')} USD｜ROI:{c.get('roi','')}｜建议:{c.get('diagnosis','')}"
    )


def campaign_short_name(c):
    name = safe_text(c.get("campaignName")).strip()
    return name or f"计划_{c.get('index','')}"


def diagnose_campaign_v10(c: dict):
    """广告管家核心规则：把每个计划转成可执行动作。"""
    name = campaign_short_name(c)
    status = safe_text(c.get("status"))
    spend = n(c.get("costUSD"))
    orders = int(n(c.get("skuOrders")))
    revenue = n(c.get("revenueUSD"))
    roi = n(c.get("roi"))
    target = n(c.get("targetROI"))
    daily = n(c.get("dailyBudgetUSD"))

    item = {
        "campaignName": name,
        "status": status,
        "dailyBudgetUSD": r2(daily),
        "costUSD": r2(spend),
        "skuOrders": orders,
        "revenueUSD": r2(revenue),
        "roi": r2(roi),
        "targetROI": r2(target),
        "action": "observe",
        "actionCN": "继续观察",
        "budgetAdvice": "不加预算",
        "suggestedBudgetUSD": r2(daily),
        "reason": "数据暂不足，先观察趋势。",
        "priority": 50,
        "risk": "normal",
    }

    # 样本太小，避免被 0.03 美金 1 单这种 ROI 误导。
    if spend > 0 and spend < 1:
        item.update({
            "action": "small_sample",
            "actionCN": "小样本，不作为加预算依据",
            "budgetAdvice": "不加预算，最多复制复盘",
            "suggestedBudgetUSD": min(20, daily or 20),
            "reason": "消耗小于 1 USD，ROI 可能是偶然成交，不能当成爆款。",
            "priority": 35,
            "risk": "sample_too_small",
        })
        return item

    if spend <= 0:
        item.update({
            "action": "no_data",
            "actionCN": "无消耗，暂不判断",
            "budgetAdvice": "不处理",
            "suggestedBudgetUSD": r2(daily),
            "reason": "计划没有产生消耗，没有足够判断依据。",
            "priority": 10,
            "risk": "no_data",
        })
        return item

    if status == "已生效" and spend < 3 and orders == 0:
        item.update({
            "action": "observe",
            "actionCN": "继续观察",
            "budgetAdvice": "保持预算，不加预算",
            "suggestedBudgetUSD": r2(daily),
            "reason": "当前消耗太少，未到判断线。先观察到 5-10 USD。",
            "priority": 45,
            "risk": "early_stage",
        })
        return item

    if status == "已生效" and spend >= 8 and orders == 0:
        item.update({
            "action": "stop_or_lower",
            "actionCN": "建议关停/降预算",
            "budgetAdvice": "先降 50% 或暂停",
            "suggestedBudgetUSD": r2(max(10, daily * 0.5 if daily else 10)),
            "reason": "生效计划已消耗 8 USD 以上仍 0 单，继续烧钱风险高。",
            "priority": 95,
            "risk": "burn_no_order",
        })
        return item

    if spend >= 5 and roi < 1:
        item.update({
            "action": "do_not_restart",
            "actionCN": "不要重开/建议关停",
            "budgetAdvice": "不加预算，暂停或不重开",
            "suggestedBudgetUSD": 0,
            "reason": "消耗已达到判断线，但 ROI 低于 1，亏损明显。",
            "priority": 90,
            "risk": "low_roi",
        })
        return item

    if orders >= 10 and roi >= 4:
        suggested = daily * 1.2 if daily else 30
        if target and roi < target:
            item.update({
                "action": "keep_review",
                "actionCN": "保留复盘，不要大幅加预算",
                "budgetAdvice": "复制复盘，预算 30-50 USD/天；原计划不大幅加预算",
                "suggestedBudgetUSD": r2(min(max(30, daily * 0.5 if daily else 30), 50)),
                "reason": "订单量和 ROI 都不错，但未达到目标 ROI，适合复盘商品/素材/时段。",
                "priority": 75,
                "risk": "target_not_met",
            })
        else:
            item.update({
                "action": "scale_20",
                "actionCN": "可小幅加预算",
                "budgetAdvice": "加预算 20%，不要翻倍",
                "suggestedBudgetUSD": r2(suggested),
                "reason": "订单数和 ROI 达到放量基础，适合小幅加预算。",
                "priority": 80,
                "risk": "low",
            })
        return item

    if orders >= 20 and roi >= 3:
        item.update({
            "action": "keep_review",
            "actionCN": "保留并复盘",
            "budgetAdvice": "保持或复制测试，预算 30-50 USD/天",
            "suggestedBudgetUSD": r2(min(max(30, daily * 0.5 if daily else 30), 50)),
            "reason": "有稳定成交，但 ROI 还没到安全放量线，适合复制复盘。",
            "priority": 70,
            "risk": "medium",
        })
        return item

    if orders > 0 and roi >= 2:
        item.update({
            "action": "observe_positive",
            "actionCN": "有成交，继续观察",
            "budgetAdvice": "保持预算，等订单 ≥5 再判断",
            "suggestedBudgetUSD": r2(daily),
            "reason": "已有成交但样本不够，先观察稳定性。",
            "priority": 60,
            "risk": "normal",
        })
        return item

    if orders > 0 and roi < 2:
        item.update({
            "action": "lower_or_adjust",
            "actionCN": "降预算/优化商品素材",
            "budgetAdvice": "不加预算，可降 20%-50%",
            "suggestedBudgetUSD": r2(max(10, daily * 0.7 if daily else 10)),
            "reason": "有订单但 ROI 偏低，先检查价格、优惠、素材匹配。",
            "priority": 65,
            "risk": "roi_weak",
        })
        return item

    return item


def build_ad_manager_plan(summary: dict, campaigns: list, change: dict):
    actions = [diagnose_campaign_v10(c) for c in (campaigns or [])]
    actions_sorted = sorted(actions, key=lambda x: x.get("priority", 0), reverse=True)

    buckets = {
        "keepNow": [x for x in actions_sorted if x["action"] in ("scale_20", "keep_review")],
        "observe": [x for x in actions_sorted if x["action"] in ("observe", "observe_positive", "small_sample")],
        "stopOrNoRestart": [x for x in actions_sorted if x["action"] in ("stop_or_lower", "do_not_restart", "lower_or_adjust")],
        "noData": [x for x in actions_sorted if x["action"] == "no_data"],
        "scaleCandidates": [x for x in actions_sorted if x["action"] == "scale_20"],
    }

    overall_roi = n(summary.get("overallROI"))
    active_count = int(n(summary.get("activeCount")))
    delta_orders = int(n(change.get("deltaOrders")))
    delta_spend = n(change.get("deltaSpendUSD"))

    budget_summary = "当前不建议整体加预算。"
    if buckets["scaleCandidates"]:
        budget_summary = "有少量可小幅放量计划，单次只加 20%，不要翻倍。"
    elif overall_roi >= 4 and delta_orders > 0:
        budget_summary = "整体表现可继续观察，但还需要看新增订单是否稳定。"
    elif delta_spend >= 3 and delta_orders <= 0:
        budget_summary = "本轮消耗增加但订单未增加，先不要加预算。"
    elif active_count == 0:
        budget_summary = "当前无生效计划，先确认是否需要重开老品或新建 Selected Products GMV Max。"

    cold_start = [
        "老品稳定计划不要频繁改，不要把新品直接塞进老品 All Products 里测试。",
        "新品使用 Selected Products GMV Max 单独开，第一组只放 3-5 个新品 SKU。",
        "新品测试预算 10-20 USD/天，观察 12-24 小时；不要一上来 200 USD。",
        "花费 5 USD 点击弱：换主图/素材；花费 8-10 USD 仍 0 单：暂停。",
        "新品出 2-3 单后进入潜力新品组，预算 20-30 USD/天继续验证。",
        "新品出 10 单且 ROI ≥4，再考虑每次 +20% 加预算。",
        "跑出来的新品再转入老品稳定组，没跑出来的直接下线，不拖预算。",
    ]

    material_next = [
        "优先复盘高订单计划对应的商品图、视频素材、前3秒钩子、价格和优惠。",
        "素材监控建议下一步读取素材消耗、CTR、订单、ROI、视频播放完成率。",
        "高点击低成交：检查商品详情、价格、运费、优惠券和机型选择。",
        "低点击有曝光：改封面、前3秒、主卖点字幕。",
    ]

    return {
        "version": VERSION,
        "generatedAt": datetime.now().isoformat(),
        "budgetSummary": budget_summary,
        "actions": actions_sorted,
        "buckets": buckets,
        "coldStartPlan": cold_start,
        "materialNextPlan": material_next,
        "importantEvents": change.get("importantEvents") or [],
        "summary": {
            "totalCampaigns": int(n(summary.get("totalCampaigns"))),
            "activeCount": active_count,
            "totalSpendUSD": r2(summary.get("totalSpendUSD")),
            "totalRevenueUSD": r2(summary.get("totalRevenueUSD")),
            "totalOrders": int(n(summary.get("totalOrders"))),
            "overallROI": r2(summary.get("overallROI")),
        }
    }


def export_operation_advice(path: Path, plan: dict):
    b = plan.get("buckets") or {}
    lines = [
        "TikTok GMV Max 广告管家 v1.3 操作建议",
        "",
        "【预算总建议】",
        plan.get("budgetSummary", ""),
        "",
        "【1. 立即保留 / 复盘】",
    ]
    keep = b.get("keepNow") or []
    if keep:
        for x in keep[:10]:
            lines.append(f"- {x['campaignName']}｜{x['actionCN']}｜{x['reason']}｜预算建议：{x['budgetAdvice']}")
    else:
        lines.append("- 暂无明确可保留放量计划")

    lines.append("")
    lines.append("【2. 继续观察】")
    obs = b.get("observe") or []
    if obs:
        for x in obs[:10]:
            lines.append(f"- {x['campaignName']}｜{x['actionCN']}｜{x['reason']}｜预算建议：{x['budgetAdvice']}")
    else:
        lines.append("- 暂无")

    lines.append("")
    lines.append("【3. 建议关停 / 不要重开 / 降预算】")
    stop = b.get("stopOrNoRestart") or []
    if stop:
        for x in stop[:10]:
            lines.append(f"- {x['campaignName']}｜{x['actionCN']}｜{x['reason']}｜预算建议：{x['budgetAdvice']}")
    else:
        lines.append("- 暂无")

    lines.append("")
    lines.append("【4. 新品冷启动 Selected Products GMV Max】")
    lines.extend(f"- {x}" for x in plan.get("coldStartPlan", []))

    lines.append("")
    lines.append("【5. 素材下一步】")
    lines.extend(f"- {x}" for x in plan.get("materialNextPlan", []))
    path.write_text("\n".join(lines), encoding="utf-8")
    return str(path)


def compare_with_previous(summary: dict, campaigns: list, meta: dict):
    prev = read_json(STATE_FILE, default={}) or {}
    fingerprint, canonical = make_fingerprint(summary, campaigns)
    prev_fingerprint = prev.get("fingerprint")
    has_previous = bool(prev_fingerprint)
    changed = fingerprint != prev_fingerprint

    prev_summary = prev.get("summary") or {}
    prev_campaigns = prev.get("campaignsByKey") or {}
    current_campaigns = campaigns_by_key(campaigns)

    delta_spend = round(n(summary.get("totalSpendUSD")) - n(prev_summary.get("totalSpendUSD")), 2) if has_previous else 0
    delta_revenue = round(n(summary.get("totalRevenueUSD")) - n(prev_summary.get("totalRevenueUSD")), 2) if has_previous else 0
    delta_orders = int(n(summary.get("totalOrders")) - n(prev_summary.get("totalOrders"))) if has_previous else 0
    delta_roi = round(n(summary.get("overallROI")) - n(prev_summary.get("overallROI")), 2) if has_previous else 0

    per_campaign = []
    events = []

    for key, cur in current_campaigns.items():
        old = prev_campaigns.get(key)
        if not old:
            per_campaign.append({"campaignName": key, "change": "new_campaign", "current": cur})
            if has_previous:
                events.append(f"新增计划：{key}")
            continue

        d_spend = round(n(cur.get("costUSD")) - n(old.get("costUSD")), 2)
        d_orders = int(n(cur.get("skuOrders")) - n(old.get("skuOrders")))
        d_revenue = round(n(cur.get("revenueUSD")) - n(old.get("revenueUSD")), 2)
        d_roi = round(n(cur.get("roi")) - n(old.get("roi")), 2)
        status_changed = cur.get("status") != old.get("status")

        if d_spend or d_orders or d_revenue or d_roi or status_changed:
            per_campaign.append({
                "campaignName": key,
                "deltaSpendUSD": d_spend,
                "deltaOrders": d_orders,
                "deltaRevenueUSD": d_revenue,
                "deltaROI": d_roi,
                "oldStatus": old.get("status"),
                "newStatus": cur.get("status"),
                "current": cur,
            })

        if d_orders > 0:
            events.append(f"新增订单：{key} +{d_orders} 单，收入 +{d_revenue} USD")
        if d_spend >= 3 and d_orders <= 0 and cur.get("status") == "已生效":
            events.append(f"消耗增加但无新增订单：{key} 花费 +{d_spend} USD，订单 +0")
        if n(cur.get("costUSD")) >= 8 and n(cur.get("skuOrders")) == 0 and cur.get("status") == "已生效":
            events.append(f"预警：{key} 已消耗 {cur.get('costUSD')} USD 仍 0 单")
        if n(old.get("roi")) >= 2 and n(cur.get("roi")) < n(old.get("roi")) * 0.7 and d_spend > 0:
            events.append(f"ROI明显下降：{key} 从 {old.get('roi')} 降到 {cur.get('roi')}")
        if status_changed:
            events.append(f"状态变化：{key} {old.get('status')} → {cur.get('status')}")

    for key in prev_campaigns.keys():
        if key not in current_campaigns:
            per_campaign.append({"campaignName": key, "change": "missing_in_current"})
            if has_previous:
                events.append(f"本次未读取到上次计划：{key}")

    no_duplicate = meta.get("noDuplicate", True) is not False
    force_send = bool(meta.get("forceSend"))
    send_only_important = bool(meta.get("sendOnlyImportant"))

    if force_send:
        should_send = True
        send_reason = "手动强制发送"
    elif not campaigns:
        should_send = True
        send_reason = "未提取到计划，可能页面未加载或当前页不是 GMV Max"
    elif not has_previous:
        should_send = True
        send_reason = "第一次采集，发送基准数据"
    elif no_duplicate and not changed:
        should_send = False
        send_reason = "和上次数据完全一致，已拦截重复发送"
    elif send_only_important and not events:
        should_send = False
        send_reason = "有轻微变化，但没有达到重要提醒条件"
    else:
        should_send = True
        send_reason = "检测到数据变化" if changed else "允许重复发送"

    change = {
        "has_previous": has_previous,
        "changed": changed,
        "fingerprint": fingerprint,
        "previousFingerprint": prev_fingerprint,
        "deltaSpendUSD": delta_spend,
        "deltaRevenueUSD": delta_revenue,
        "deltaOrders": delta_orders,
        "deltaROI": delta_roi,
        "perCampaignChanges": per_campaign[:50],
        "importantEvents": events[:30],
        "eventCount": len(events),
        "shouldSend": should_send,
        "sendReason": send_reason,
        "previousUpdatedAt": prev.get("updatedAt", ""),
    }

    new_state = {
        "version": VERSION,
        "updatedAt": datetime.now().isoformat(),
        "fingerprint": fingerprint,
        "summary": canonical["summary"],
        "campaignsByKey": current_campaigns,
    }
    return change, new_state


def build_chatgpt_message(snapshot: dict, summary: dict, campaigns: list, folder: Path, meta: dict, change: dict, plan: dict = None):
    brief = build_brief(summary, campaigns)
    captured = snapshot.get("capturedAt") or datetime.now().isoformat()
    url = snapshot.get("url", "")
    auto = "自动定时采集" if meta.get("auto") else "手动采集"

    lines = []
    lines.append("这是我的 TikTok GMV Max 广告管家 v1.3 数据，请帮我根据【广告管家建议】复核哪些计划该保留、关停、降预算、加预算，以及新品冷启动怎么安排。")
    lines.append("")
    lines.append(f"采集方式：{auto}")
    lines.append(f"采集时间：{captured}")
    lines.append(f"页面：{url}")
    lines.append(f"翻页读取：{summary.get('pagesRead', 1)} 页，自动翻页：{summary.get('autoPaginated', False)}")
    lines.append(f"发送原因：{change.get('sendReason','')}")
    lines.append("")
    if plan:
        lines.append("【广告管家建议】")
        lines.append(f"预算总建议：{plan.get('budgetSummary','')}")
        buckets = plan.get('buckets') or {}
        keep = buckets.get('keepNow') or []
        obs = buckets.get('observe') or []
        stop = buckets.get('stopOrNoRestart') or []
        lines.append(f"立即保留/复盘：{len(keep)} 个；继续观察：{len(obs)} 个；建议关停/降预算/不重开：{len(stop)} 个")
        for title, arr in (("保留/复盘", keep[:5]), ("观察", obs[:5]), ("关停/降预算", stop[:5])):
            if arr:
                lines.append(f"{title}：")
                for x in arr:
                    lines.append(f"- {x.get('campaignName')}｜{x.get('actionCN')}｜{x.get('reason')}｜{x.get('budgetAdvice')}")
        lines.append("")
    lines.append("【相比上次变化】")
    if not change.get("has_previous"):
        lines.append("第一次采集，暂无上次数据，用作后续监控基准。")
    else:
        lines.append(f"消耗：{change.get('deltaSpendUSD',0)} USD")
        lines.append(f"收入：{change.get('deltaRevenueUSD',0)} USD")
        lines.append(f"订单：{change.get('deltaOrders',0)}")
        lines.append(f"整体 ROI 变化：{change.get('deltaROI',0)}")
        if not change.get("changed"):
            lines.append("结论：和上次采集完全一致，本次理论上不需要重复分析。")
    lines.append("")
    lines.append("【重要变化/预警】")
    events = change.get("importantEvents") or []
    if events:
        lines.extend(f"- {x}" for x in events[:10])
    else:
        lines.append("- 暂无重要变化")
    lines.append("")
    lines.append("【总览】")
    lines.append(f"广告计划数：{brief['totalCampaigns']}")
    lines.append(f"生效计划：{brief['activeCount']}，暂停计划：{brief['pausedCount']}")
    lines.append(f"总消耗：{brief['totalSpendUSD']} USD")
    lines.append(f"总收入：{brief['totalRevenueUSD']} USD")
    lines.append(f"SKU订单数：{brief['totalOrders']}")
    lines.append(f"整体ROI：{brief['overallROI']}")
    lines.append(f"疑似应关停/降预算：{brief['stopCandidateCount']} 个")
    lines.append(f"疑似可保留复盘：{brief['goodCandidateCount']} 个")
    lines.append(f"数据太少继续观察：{brief['observingCount']} 个")
    lines.append("")
    lines.append("【表现较好的计划，最多5个】")
    if brief["best"]:
        lines.extend(fmt_campaign(c) for c in brief["best"])
    else:
        lines.append("- 暂无")
    lines.append("")
    lines.append("【表现较差/需注意的计划，最多5个】")
    if brief["worst"]:
        lines.extend(fmt_campaign(c) for c in brief["worst"])
    else:
        lines.append("- 暂无")
    lines.append("")
    active_campaigns = [c for c in campaigns if c.get("status") == "已生效"][:10]
    changed_names = {x.get("campaignName") for x in (change.get("perCampaignChanges") or []) if x.get("campaignName")}
    changed_campaigns = [c for c in campaigns if c.get("campaignName") in changed_names][:10]
    lines.append("【正在生效计划，最多10个】")
    if active_campaigns:
        lines.extend(fmt_campaign(c) for c in active_campaigns)
    else:
        lines.append("- 暂无")
    lines.append("")
    lines.append("【本次有变化计划，最多10个】")
    if changed_campaigns:
        lines.extend(fmt_campaign(c) for c in changed_campaigns)
    else:
        lines.append("- 暂无")
    lines.append("")
    lines.append("请按照下面格式输出：")
    lines.append("1. 立即保留的计划")
    lines.append("2. 继续观察的计划")
    lines.append("3. 建议关停/不要重开的计划")
    lines.append("4. 是否加预算，以及加多少")
    lines.append("5. 新品 Selected Products GMV Max 怎么开，避免影响老品")
    lines.append("")
    lines.append(f"本地文件夹：{folder}")
    lines.append("备注：完整 CSV 在 gmv_campaigns.csv，截图在 screenshot.png，变化记录在 change.json。")
    return "\n".join(lines)


def export_summary_txt(path: Path, summary: dict, change: dict):
    lines = [
        "TikTok GMV Max 广告管家版 v1.3 摘要",
        "",
        f"广告计划数：{summary.get('totalCampaigns', 0)}",
        f"生效计划：{summary.get('activeCount', 0)}",
        f"暂停计划：{summary.get('pausedCount', 0)}",
        f"总消耗：{summary.get('totalSpendUSD', 0)} USD",
        f"总收入：{summary.get('totalRevenueUSD', 0)} USD",
        f"SKU订单数：{summary.get('totalOrders', 0)}",
        f"整体ROI：{summary.get('overallROI', 0)}",
        f"可见日预算合计：{summary.get('visibleBudgetUSD', 0)} USD",
        f"提取来源：{summary.get('source', '')}",
        "",
        "相比上次变化：",
        f"是否有上次数据：{change.get('has_previous')}",
        f"是否变化：{change.get('changed')}",
        f"消耗变化：{change.get('deltaSpendUSD',0)} USD",
        f"收入变化：{change.get('deltaRevenueUSD',0)} USD",
        f"订单变化：{change.get('deltaOrders',0)}",
        f"ROI变化：{change.get('deltaROI',0)}",
        f"是否建议发送：{change.get('shouldSend')}",
        f"发送原因：{change.get('sendReason','')}",
    ]
    events = change.get("importantEvents") or []
    if events:
        lines.append("")
        lines.append("重要变化/预警：")
        lines.extend(f"- {x}" for x in events[:20])
    path.write_text("\n".join(lines), encoding="utf-8")
    return str(path)


def append_log(record: dict):
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")



def generate_dashboard_html():
    latest = None
    folders = [x for x in ROOT.iterdir() if x.is_dir()]
    folders.sort(key=lambda x: x.name, reverse=True)
    if folders:
        folder = folders[0]
        summary_wrap = read_json(folder / "gmv_campaigns.json", default={}) or {}
        change = read_json(folder / "change.json", default={}) or {}
        plan = read_json(folder / "operation_plan.json", default={}) or {}
        latest = {"folder": folder, "summary": summary_wrap.get("summary") or {}, "change": change, "plan": plan}

    rows = []
    try:
        if LOG_FILE.exists():
            lines = LOG_FILE.read_text(encoding="utf-8").splitlines()[-20:]
            for line in reversed(lines):
                item = json.loads(line)
                s = item.get("summary") or {}
                rows.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                    safe_text(item.get('time')), safe_text(s.get('totalSpendUSD')), safe_text(s.get('totalOrders')),
                    safe_text(s.get('totalRevenueUSD')), safe_text(s.get('overallROI')), safe_text(item.get('send_reason'))
                ))
    except Exception:
        pass

    s = latest["summary"] if latest else {}
    ch = latest["change"] if latest else {}
    plan = latest.get("plan") if latest else {}
    buckets = (plan or {}).get("buckets") or {}
    events = ch.get("importantEvents") or []
    event_html = "".join("<li>{}</li>".format(safe_text(e)) for e in events[:10]) or "<li>暂无重要预警</li>"

    def card_list(items):
        if not items:
            return "<li>暂无</li>"
        return "".join("<li><b>{}</b><br><span>{}｜{}｜{}</span></li>".format(
            safe_text(x.get('campaignName')), safe_text(x.get('actionCN')), safe_text(x.get('reason')), safe_text(x.get('budgetAdvice'))
        ) for x in items[:8])

    html = """<!doctype html><html><head><meta charset=\"utf-8\"><title>GMV Max 广告管家 v1.3</title>
<style>
body{{font-family:Arial,'Microsoft YaHei',sans-serif;background:#f5f6f8;margin:0;padding:18px;color:#111}}
.card{{background:#fff;border:1px solid #ddd;border-radius:12px;padding:14px;margin:12px 0;box-shadow:0 1px 2px rgba(0,0,0,.03)}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.cols{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}}
.kpi{{background:#111;color:#fff;border-radius:12px;padding:14px}}.kpi b{{font-size:25px}}
table{{width:100%;border-collapse:collapse;background:#fff}}td,th{{border:1px solid #ddd;padding:8px;font-size:13px}}
.small{{color:#555;font-size:12px}}ul{{padding-left:20px}}li{{margin:8px 0}}.ok{{border-left:5px solid #159947}}.warn{{border-left:5px solid #e5a100}}.bad{{border-left:5px solid #cc3333}}
.btn{{display:inline-block;background:#111;color:#fff;padding:8px 12px;border-radius:8px;text-decoration:none;margin-right:8px}}
</style></head><body>
<h1>TikTok GMV Max 广告管家 v1.3</h1>
<div class=\"small\">本地地址：http://127.0.0.1:{port}/dashboard ｜ 最新文件夹：{folder}</div>
<div class=\"grid\">
<div class=\"kpi\">总消耗<br><b>{spend}</b> USD</div>
<div class=\"kpi\">订单<br><b>{orders}</b></div>
<div class=\"kpi\">总收入<br><b>{revenue}</b> USD</div>
<div class=\"kpi\">ROI<br><b>{roi}</b></div>
</div>
<div class=\"card\"><h2>广告管家总建议</h2><p><b>{budget_summary}</b></p><p>消耗变化：{dspend} USD ｜ 订单变化：{dorders} ｜ 收入变化：{drevenue} USD ｜ ROI变化：{droi}</p><p>发送原因：{reason}</p><ul>{events}</ul></div>
<div class=\"cols\">
<div class=\"card ok\"><h2>保留 / 复盘</h2><ul>{keep}</ul></div>
<div class=\"card warn\"><h2>继续观察</h2><ul>{observe}</ul></div>
<div class=\"card bad\"><h2>关停 / 降预算</h2><ul>{stop}</ul></div>
</div>
<div class=\"card\"><h2>新品 Selected Products GMV Max 冷启动</h2><ul>{cold}</ul></div>
<div class=\"card\"><h2>素材下一步</h2><ul>{material}</ul></div>
<div class=\"card\"><h2>最近20次采集</h2><table><tr><th>时间</th><th>消耗USD</th><th>订单</th><th>收入USD</th><th>ROI</th><th>发送原因</th></tr>{rows}</table></div>
</body></html>""".format(
        port=PORT, folder=safe_text(latest['folder'] if latest else ''),
        spend=s.get('totalSpendUSD',0), orders=s.get('totalOrders',0), revenue=s.get('totalRevenueUSD',0), roi=s.get('overallROI',0),
        dspend=ch.get('deltaSpendUSD',0), dorders=ch.get('deltaOrders',0), drevenue=ch.get('deltaRevenueUSD',0), droi=ch.get('deltaROI',0),
        reason=safe_text(ch.get('sendReason','')), events=event_html, rows="".join(rows),
        budget_summary=safe_text((plan or {}).get('budgetSummary','暂无建议，先采集一次数据。')),
        keep=card_list(buckets.get('keepNow') or []), observe=card_list(buckets.get('observe') or []), stop=card_list(buckets.get('stopOrNoRestart') or []),
        cold="".join("<li>{}</li>".format(safe_text(x)) for x in ((plan or {}).get('coldStartPlan') or [])) or "<li>采集后生成</li>",
        material="".join("<li>{}</li>".format(safe_text(x)) for x in ((plan or {}).get('materialNextPlan') or [])) or "<li>采集后生成</li>"
    )
    return html

class Handler(BaseHTTPRequestHandler):
    def _headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Request-Private-Network")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _send_json(self, obj, status=200):
        self._headers(status)
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self._send_json({"ok": True})

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/creative-dashboard":
            self._headers(200, "text/html; charset=utf-8")
            self.wfile.write(generate_creative_dashboard_html().encode("utf-8"))
            return
        if path == "/dashboard":
            self._headers(200, "text/html; charset=utf-8")
            self.wfile.write(generate_dashboard_html().encode("utf-8"))
            return
        if path in ("/", "/health"):
            self._send_json({
                "ok": True,
                "name": "浏览器管家本地端",
                "version": VERSION,
                "listen": f"http://{HOST}:{PORT}",
                "save_root": str(ROOT),
                "note": "v1.5 支持素材定时监控、素材 Dashboard、素材评分分级、复制重拍建议、变化对比、无变化不重复发送"
            })
            return
        if path == "/state":
            self._send_json({
                "ok": True,
                "version": VERSION,
                "state_file": str(STATE_FILE),
                "state": read_json(STATE_FILE, default={}) or {}
            })
            return
        if path in ("/latest", "/latest-message"):
            folders = [p for p in ROOT.iterdir() if p.is_dir()]
            folders.sort(key=lambda p: p.name, reverse=True)
            if not folders:
                self._send_json({"ok": False, "error": "暂无快照"}, status=404)
                return
            folder = folders[0]
            summary_file = folder / "summary.txt"
            chatgpt_file = folder / "chatgpt_message.txt"
            change_file = folder / "change.json"
            operation_file = folder / "operation_plan.json"
            operation_advice_file = folder / "operation_advice.txt"
            self._send_json({
                "ok": True,
                "version": VERSION,
                "latest_dir": str(folder),
                "summary_text": summary_file.read_text(encoding="utf-8") if summary_file.exists() else "",
                "chatgpt_message_text": chatgpt_file.read_text(encoding="utf-8") if chatgpt_file.exists() else "",
                "chatgpt_message_file": str(chatgpt_file) if chatgpt_file.exists() else None,
                "change": read_json(change_file, default={}) if change_file.exists() else {},
                "operation_plan": read_json(operation_file, default={}) if operation_file.exists() else {},
                "operation_advice_text": operation_advice_file.read_text(encoding="utf-8") if operation_advice_file.exists() else "",
                "files": [str(x) for x in folder.iterdir()]
            })
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self):
        if self.path != "/snapshot":
            self._send_json({"ok": False, "error": "not found"}, status=404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            data = json.loads(raw or "{}")

            now = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = ROOT / now
            folder.mkdir(parents=True, exist_ok=True)

            snapshot = data.get("snapshot") or {}
            meta = data.get("meta") or {}
            write_json(folder / "snapshot.json", snapshot)
            write_json(folder / "meta.json", meta)

            page_text = snapshot.get("pageText")
            if page_text:
                (folder / "page_text.txt").write_text(safe_text(page_text), encoding="utf-8")

            gmv = snapshot.get("gmv") or data.get("gmv") or {}
            if gmv is None:
                gmv = {}
            summary = gmv.get("summary") or {}
            campaigns = gmv.get("campaigns") or gmv.get("items") or []
            creative = snapshot.get("creative") or data.get("creative") or {}
            creative_items = creative.get("items") or []
            is_creative_import = bool(creative_items) or meta.get("pageType") == "creative" or snapshot.get("isCreativeImportTest")

            if campaigns or (gmv and not is_creative_import):
                change, new_state = compare_with_previous(summary, campaigns, meta)
                operation_plan = build_ad_manager_plan(summary, campaigns, change)
            else:
                change = {
                    "has_previous": False,
                    "shouldSend": True,
                    "sendReason": "creative_diagnosis",
                    "important": True,
                    "note": "素材诊断，不参与 GMV Max 计划状态对比。"
                }
                new_state = None
                operation_plan = {"version": VERSION, "mode": "creative_diagnosis", "summary": "素材诊断，不生成预算建议。"}
            write_json(folder / "change.json", change)
            write_json(folder / "operation_plan.json", operation_plan)
            operation_advice_file = folder / "operation_advice.txt"
            if campaigns or (gmv and not is_creative_import):
                export_operation_advice(operation_advice_file, operation_plan)
            else:
                operation_advice_file.write_text("素材诊断，不生成 GMV Max 预算建议。", encoding="utf-8")

            gmv_json_file = None
            gmv_campaigns_csv = None
            gmv_items_csv = None
            creative_json_file = None
            creative_items_csv = None
            creative_diagnosis_file = None
            creative_diagnosis_csv = None
            creative_analysis = None
            summary_file = None
            chatgpt_file = None
            chatgpt_message_text = ""
            if gmv and not is_creative_import:
                gmv_json_file = folder / "gmv_campaigns.json"
                write_json(gmv_json_file, gmv)
                summary_file = folder / "summary.txt"
                export_summary_txt(summary_file, summary, change)
                gmv_campaigns_csv = export_campaign_csv(folder / "gmv_campaigns.csv", campaigns)
                gmv_items_csv = export_campaign_csv(folder / "gmv_items.csv", campaigns)
                chatgpt_file = folder / "chatgpt_message.txt"
                chatgpt_message_text = build_chatgpt_message(snapshot, summary, campaigns, folder, meta, change, operation_plan)
                chatgpt_file.write_text(chatgpt_message_text, encoding="utf-8")
            if creative:
                creative_analysis = build_creative_analysis(creative)
                creative_score = build_creative_score(creative_analysis)
                creative_change, creative_state = compare_creative_with_previous(creative_analysis, meta)
                change = creative_change
                write_json(folder / "change.json", change)
                write_json(folder / "creative_change.json", creative_change)
                write_json(CREATIVE_STATE_FILE, creative_state)
                diagnosed_items = creative_analysis.get("items") or creative_items
                creative_with_diagnosis = dict(creative)
                creative_with_diagnosis["items"] = diagnosed_items
                creative_json_file = folder / "creative_items.json"
                write_json(creative_json_file, creative_with_diagnosis)
                creative_items_csv = export_creative_csv(folder / "creative_items.csv", diagnosed_items)
                creative_diagnosis_file = folder / "creative_diagnosis.json"
                creative_analysis["change"] = creative_change
                write_json(creative_diagnosis_file, creative_analysis)
                creative_diagnosis_csv = export_creative_diagnosis_csv(folder / "creative_diagnosis.csv", creative_analysis)
                creative_score_file = folder / "creative_score.json"
                creative_score["change"] = creative_change
                write_json(creative_score_file, creative_score)
                creative_score_csv = export_creative_score_csv(folder / "creative_score.csv", creative_score)
                creative_advice_file = folder / "creative_advice.txt"
                export_creative_advice(creative_advice_file, creative_score)
                chatgpt_file = folder / "chatgpt_message.txt"
                chatgpt_message_text = build_creative_diagnosis_message(snapshot, creative, creative_analysis, folder, meta, creative_change)
                chatgpt_file.write_text(chatgpt_message_text, encoding="utf-8")

            screenshot_data_url = data.get("screenshotDataUrl")
            screenshot_path = None
            if screenshot_data_url:
                m = re.match(r"^data:image/\w+;base64,(.+)$", screenshot_data_url)
                if m:
                    screenshot_path = folder / "screenshot.png"
                    screenshot_path.write_bytes(base64.b64decode(m.group(1)))

            # GMV Max 计划采集才更新基准状态；素材诊断不覆盖 GMV 状态。
            if new_state is not None:
                write_json(STATE_FILE, new_state)

            response = {
                "ok": True,
                "version": VERSION,
                "saved_dir": str(folder),
                "snapshot_file": str(folder / "snapshot.json"),
                "meta_file": str(folder / "meta.json"),
                "page_text_file": str(folder / "page_text.txt") if page_text else None,
                "summary_file": str(summary_file) if summary_file else None,
                "chatgpt_message_file": str(chatgpt_file) if chatgpt_file else None,
                "chatgpt_message_text": chatgpt_message_text,
                "gmv_json_file": str(gmv_json_file) if gmv_json_file else None,
                "gmv_campaigns_csv_file": gmv_campaigns_csv,
                "gmv_items_csv_file": gmv_items_csv,
                "creative_json_file": str(creative_json_file) if creative_json_file else None,
                "creative_items_csv_file": creative_items_csv,
                "creative_diagnosis_file": str(creative_diagnosis_file) if creative_diagnosis_file else None,
                "creative_diagnosis_csv_file": creative_diagnosis_csv,
                "creative_change_file": str(folder / "creative_change.json") if creative else None,
                "creative_score_file": str(folder / "creative_score.json") if creative else None,
                "creative_score_csv_file": str(folder / "creative_score.csv") if creative else None,
                "creative_advice_file": str(folder / "creative_advice.txt") if creative else None,
                "creative_dashboard_url": f"http://{HOST}:{PORT}/creative-dashboard" if creative else None,
                "creative_count": len(creative_items),
                "creative_analysis": creative_analysis,
                "creative": creative,
                "screenshot_file": str(screenshot_path) if screenshot_path else None,
                "change_file": str(folder / "change.json"),
                "operation_plan_file": str(folder / "operation_plan.json"),
                "operation_advice_file": str(operation_advice_file),
                "operation_plan": operation_plan,
                "campaign_count": len(campaigns),
                "summary": summary,
                "change": change,
                "should_send": bool(change.get("shouldSend")),
                "send_reason": change.get("sendReason", ""),
                "auto": bool(meta.get("auto")),
            }
            append_log({"time": datetime.now().isoformat(), **response})
            self._send_json(response)
        except Exception as e:
            self._send_json({
                "ok": False,
                "error": str(e),
                "traceback": traceback.format_exc()[-2000:]
            }, status=500)

    def log_message(self, fmt, *args):
        print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), fmt % args))


def check_port_available(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


if __name__ == "__main__":
    if not check_port_available(HOST, PORT):
        print(f"端口 {PORT} 已被占用。请先关闭旧的 local_agent.py 黑窗口，或运行 kill_8774_then_start.bat。")
        sys.exit(1)
    print(f"本地管家已启动：http://{HOST}:{PORT}")
    print(f"健康检测：http://{HOST}:{PORT}/health")
    print(f"最新快照：http://{HOST}:{PORT}/latest")
    print(f"状态文件：http://{HOST}:{PORT}/state")
    print(f"GMV监控面板：http://{HOST}:{PORT}/dashboard")
    print(f"素材Dashboard：http://{HOST}:{PORT}/creative-dashboard")
    print(f"快照保存目录：{ROOT}")
    print("v1.5：新增素材 Dashboard + 素材评分分级，输出 creative_score.csv、creative_advice.txt，并保留素材定时监控。")
    print("运行后不要关闭这个黑窗口。")
    HTTPServer((HOST, PORT), Handler).serve_forever()
