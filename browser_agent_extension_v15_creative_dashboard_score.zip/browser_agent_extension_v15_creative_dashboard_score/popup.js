let lastData = null;
let lastScreenshot = null;
const LOCAL_URLS = ["http://127.0.0.1:8774", "http://localhost:8774"];
let LOCAL_URL = LOCAL_URLS[0];
const VERSION = "1.5.0";

async function localFetch(path, options = {}) {
  let lastErr = null;
  for (const base of LOCAL_URLS) {
    try {
      const resp = await fetch(`${base}${path}`, { cache: "no-store", ...options });
      LOCAL_URL = base;
      return resp;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("无法连接本地管家");
}

const $ = (id) => document.getElementById(id);

function setStatus(text) {
  const el = $("status");
  if (el) el.textContent = text;
}

function show(obj) {
  lastData = obj;
  const el = $("output");
  if (el) el.value = JSON.stringify(obj, null, 2);
}

function checked(id, defaultValue = false) {
  const el = $(id);
  return el ? !!el.checked : defaultValue;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) throw new Error("找不到当前标签页");
  return tab;
}

async function ensureContent(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "PING_V10" });
    if (pong && pong.ok && pong.version === VERSION) return;
  } catch (_) {}
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
}

async function messageContent(type, payload = {}) {
  const tab = await getActiveTab();
  await ensureContent(tab.id);
  return await chrome.tabs.sendMessage(tab.id, { type, ...payload });
}

async function readJsonResponse(resp) {
  const text = await resp.text();
  let json = null;
  try { json = JSON.parse(text); }
  catch (e) {
    const short = text.slice(0, 180).replace(/\s+/g, " ");
    throw new Error(`本地管家没有返回 JSON，HTTP ${resp.status}，返回内容：${short}`);
  }
  if (!resp.ok) throw new Error(json.error || `HTTP ${resp.status}`);
  return json;
}

async function autoCheckLocalAgent() {
  try {
    setStatus("正在自动检测本地管家…");
    const resp = await localFetch(`/health`, { method: "GET" });
    const json = await readJsonResponse(resp);
    await chrome.storage.local.set({ lastHealthOkAt: Date.now(), lastHealth: json });
    setStatus("v1.5 本地管家正常运行\n" + json.listen + "\n" + (json.note || ""));
    show(json);
  } catch (e) {
    const data = await chrome.storage.local.get(["lastHealthOkAt"]);
    const last = data.lastHealthOkAt ? new Date(data.lastHealthOkAt).toLocaleString() : "无";
    setStatus("未连接：没有检测到 8774 本地管家。\n上次连接成功：" + last + "\n处理：打开 start_agent_no_flash.bat，或者运行 kill_8774_then_start.bat 后重试。\n详情：" + e.message);
  }
}

async function captureScreenshot() {
  const res = await chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" });
  if (!res.ok) throw new Error(res.error || "截图失败");
  lastScreenshot = res.dataUrl;
  return res.dataUrl;
}

async function sendLocal(payload, meta = {}) {
  const body = {
    snapshot: payload,
    screenshotDataUrl: lastScreenshot,
    meta: { auto: false, reason: "popup_manual", forceSend: true, noDuplicate: false, ...meta }
  };
  const resp = await localFetch(`/snapshot`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return await readJsonResponse(resp);
}

function bind(id, fn) {
  const el = $(id);
  if (el) el.addEventListener("click", fn);
}

bind("snapshotBtn", async () => {
  try {
    setStatus("正在读取页面…");
    const res = await messageContent("GET_SNAPSHOT_V10");
    if (!res.ok) throw new Error(res.error || "读取失败");
    show(res.snapshot);
    const s = res.snapshot?.gmv?.summary || {};
    setStatus(`页面已读取，GMV 计划：${s.totalCampaigns || 0} 条；页面识别：${res.snapshot?.isGmvMaxPage ? "GMV Max" : "未知/非GMV"}`);
  } catch (e) {
    setStatus("读取失败：" + e.message);
  }
});

bind("gmvBtn", async () => {
  try {
    setStatus("正在提取 GMV Max 表格…");
    const res = await messageContent("GET_GMV_V10");
    if (!res.ok) throw new Error(res.error || "提取失败");
    show(res);
    const s = res.gmv?.summary || {};
    setStatus(`已提取计划：${s.totalCampaigns || 0} 条；生效 ${s.activeCount || 0}，暂停 ${s.pausedCount || 0}`);
  } catch (e) {
    setStatus("提取失败：" + e.message);
  }
});

bind("screenshotBtn", async () => {
  try {
    setStatus("正在截图…");
    const dataUrl = await captureScreenshot();
    show({ ...(lastData || {}), screenshotDataUrl: dataUrl.slice(0, 80) + "...", screenshotBytesApprox: Math.round(dataUrl.length * 0.75) });
    setStatus("截图已完成，可发送到本地管家保存完整图片");
  } catch (e) {
    setStatus("截图失败：" + e.message);
  }
});

bind("copyBtn", async () => {
  try {
    const text = $("output").value || JSON.stringify(lastData || {}, null, 2);
    await navigator.clipboard.writeText(text);
    setStatus("已复制到剪贴板");
  } catch (e) {
    setStatus("复制失败：" + e.message);
  }
});

bind("sendLocalBtn", async () => {
  try {
    setStatus("正在发送到本地管家…");
    let payload = lastData;
    if (!payload || !payload.gmv) {
      const res = await messageContent("GET_SNAPSHOT_V10");
      if (!res.ok) throw new Error(res.error || "读取失败");
      payload = res.snapshot;
    }
    const json = await sendLocal(payload, { reason: "popup_manual_send_local", forceSend: true });
    setStatus("已保存到本地：" + json.saved_dir + `\n发送判断：${json.should_send ? "可发送" : "无变化不发送"}；${json.send_reason || ""}`);
    show(json);
  } catch (e) {
    setStatus("发送失败：请先运行 v1.5 的 local_agent.py。详情：" + e.message);
  }
});

bind("saveAllBtn", async () => {
  try {
    setStatus("正在读取页面…");
    const res = await messageContent("GET_SNAPSHOT_V10");
    if (!res.ok) throw new Error(res.error || "读取失败");
    lastData = res.snapshot;
    setStatus("正在截图…");
    await captureScreenshot();
    setStatus("正在保存到本地…");
    const json = await sendLocal(lastData, { reason: "popup_save_all", forceSend: true });
    setStatus("已保存到本地：" + json.saved_dir);
    show(json);
  } catch (e) {
    setStatus("一键保存失败：请先运行 v1.5 的 local_agent.py。详情：" + e.message);
  }
});

bind("healthBtn", async () => {
  try {
    setStatus("正在检测本地管家…");
    const resp = await localFetch(`/health`, { method: "GET" });
    const json = await readJsonResponse(resp);
    show(json);
    setStatus("v1.5 本地管家正常运行\n" + json.listen + "\n" + (json.note || ""));
  } catch (e) {
    setStatus("本地管家未连接：请在 v1.5 插件文件夹运行 python local_agent.py。详情：" + e.message);
  }
});



bind("creativeDashboardBtn", async () => {
  try {
    await chrome.tabs.create({ url: `${LOCAL_URL}/creative-dashboard`, active: true });
    setStatus("已打开素材 Dashboard v1.5");
  } catch (e) {
    setStatus("打开素材 Dashboard 失败：" + e.message);
  }
});

bind("dashboardBtn", async () => {
  try {
    await chrome.tabs.create({ url: `${LOCAL_URL}/dashboard`, active: true });
    setStatus("已打开本地监控面板");
  } catch (e) {
    setStatus("打开监控面板失败：" + e.message);
  }
});



bind("saveCreativeUrlBtn", async () => {
  try {
    setStatus("正在保存当前素材页地址…");
    const res = await chrome.runtime.sendMessage({ type: "SAVE_CREATIVE_URL_V11" });
    if (!res.ok) throw new Error(res.error || "保存失败");
    show(res);
    setStatus("已保存素材页地址。以后可以点“打开素材页并填入”。\n" + res.savedCreativeUrl);
  } catch (e) {
    setStatus("保存素材页失败：" + e.message);
  }
});

async function runCreativeImport(mode) {
  let waitSeconds = Number($("creativeWaitSeconds")?.value || 30);
  if (!Number.isFinite(waitSeconds) || waitSeconds < 5) waitSeconds = 30;
  await chrome.storage.local.set({ creativeWaitSeconds: waitSeconds });
  setStatus(`正在打开素材页，等待 ${waitSeconds} 秒后采集…弹窗可以关闭。已保存为素材诊断默认等待时间。`);
  const res = await chrome.runtime.sendMessage({
    type: "CREATIVE_IMPORT_CHATGPT_V11",
    options: {
      chatgptMode: mode,
      waitAfterOpenMs: Math.max(5, waitSeconds) * 1000,
      useCurrent: false
    }
  });
  if (!res.ok) throw new Error(res.error || "素材诊断失败");
  show(res);
  if (res.job_started) {
    const sec = res.delaySeconds || waitSeconds;
    setStatus(mode === "send"
      ? `素材诊断发送任务已启动：已打开素材页，后台等待约 ${sec} 秒后采集并自动发送。弹窗可以关闭，稍后点“素材诊断状态”查看结果。`
      : `素材诊断填入任务已启动：已打开素材页，后台等待约 ${sec} 秒后采集并填入 ChatGPT。弹窗可以关闭，稍后点“素材诊断状态”查看结果。`);
  } else {
    setStatus(mode === "send" ? "素材数据已采集，并尝试自动发送到 ChatGPT。" : "素材数据已采集，并填入 ChatGPT，请确认后手动发送。");
  }
}

bind("creativeImportPasteBtn", async () => {
  try { await runCreativeImport("paste"); }
  catch (e) { setStatus("素材诊断填入失败：" + e.message); }
});

bind("creativeImportSendBtn", async () => {
  try { await runCreativeImport("send"); }
  catch (e) { setStatus("素材诊断发送失败：" + e.message); }
});


async function runCurrentCreative(mode) {
  setStatus(mode === "send" ? "正在读取当前素材页并发送，不刷新页面…" : "正在读取当前素材页并填入，不刷新页面…");
  const res = await chrome.runtime.sendMessage({
    type: "CREATIVE_CURRENT_CHATGPT_V121",
    options: { chatgptMode: mode }
  });
  if (!res.ok) throw new Error(res.error || "读取当前素材页失败");
  show(res);
  setStatus(mode === "send" ? "当前素材页已读取，并尝试发送到 ChatGPT。" : "当前素材页已读取，并填入 ChatGPT，请确认后发送。");
}

bind("creativeCurrentPasteBtn", async () => {
  try { await runCurrentCreative("paste"); }
  catch (e) { setStatus("读取当前素材页填入失败：" + e.message); }
});

bind("creativeCurrentSendBtn", async () => {
  try { await runCurrentCreative("send"); }
  catch (e) { setStatus("读取当前素材页发送失败：" + e.message); }
});

async function runRefreshCreative(mode) {
  let waitSeconds = Number($("creativeWaitSeconds")?.value || 30);
  if (!Number.isFinite(waitSeconds) || waitSeconds < 5) waitSeconds = 30;
  await chrome.storage.local.set({ creativeWaitSeconds: waitSeconds });
  setStatus(mode === "send"
    ? `正在刷新当前素材页，等待 ${waitSeconds} 秒后采集并发送…弹窗可以关闭。`
    : `正在刷新当前素材页，等待 ${waitSeconds} 秒后采集并填入…弹窗可以关闭。`);
  const res = await chrome.runtime.sendMessage({
    type: "CREATIVE_REFRESH_CURRENT_CHATGPT_V122",
    options: { chatgptMode: mode, waitAfterRefreshMs: Math.max(5, waitSeconds) * 1000 }
  });
  if (!res.ok) throw new Error(res.error || "刷新当前素材页失败");
  show(res);
  if (res.job_started) {
    const sec = res.delaySeconds || waitSeconds;
    setStatus(mode === "send"
      ? `素材页刷新任务已启动：后台等待约 ${sec} 秒后采集并自动发送。`
      : `素材页刷新任务已启动：后台等待约 ${sec} 秒后采集并填入 ChatGPT。`);
  } else {
    setStatus(mode === "send" ? "当前素材页已刷新采集，并尝试发送到 ChatGPT。" : "当前素材页已刷新采集，并填入 ChatGPT，请确认后发送。");
  }
}

bind("creativeRefreshPasteBtn", async () => {
  try { await runRefreshCreative("paste"); }
  catch (e) { setStatus("刷新当前素材页填入失败：" + e.message); }
});

bind("creativeRefreshSendBtn", async () => {
  try { await runRefreshCreative("send"); }
  catch (e) { setStatus("刷新当前素材页发送失败：" + e.message); }
});

bind("creativeStatusBtn", async () => {
  try {
    const res = await chrome.runtime.sendMessage({ type: "GET_CREATIVE_STATUS_V11" });
    if (!res.ok) throw new Error(res.error || "读取失败");
    show(res);
    const job = res.currentCreativeImportJob;
    const jobText = job ? (`\n当前任务：${job.state || "运行中"}，预计等待 ${Math.round((job.waitAfterOpenMs || 0)/1000)} 秒`) : "\n当前任务：无";
    const last = res.lastCreativeImportResult;
    const lastText = last?.chatgpt ? (last.chatgpt.autoClickSend ? "已尝试自动发送" : "已填入等待手动发送") : (last?.saved?.saved_dir || "无");
    setStatus("素材页地址：\n" + (res.savedCreativeUrl || "还没保存") + "\n最近诊断：" + lastText + jobText);
  } catch (e) {
    setStatus("读取素材状态失败：" + e.message);
  }
});

bind("creativeLatestSendBtn", async () => {
  try {
    setStatus("正在发送最新素材消息到 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "OPEN_LATEST_CHATGPT_V10", autoClickSend: true });
    if (!res.ok) throw new Error(res.error || "发送失败");
    show(res);
    setStatus("已尝试发送最新素材消息到 ChatGPT。 ");
  } catch (e) {
    setStatus("发送最新素材消息失败：" + e.message);
  }
});

const creativeWaitInput = $("creativeWaitSeconds");
if (creativeWaitInput) {
  creativeWaitInput.addEventListener("change", async () => {
    let v = Number(creativeWaitInput.value || 30);
    if (!Number.isFinite(v) || v < 5) v = 30;
    creativeWaitInput.value = String(v);
    await chrome.storage.local.set({ creativeWaitSeconds: v });
    setStatus(`素材诊断等待秒数已保存：${v} 秒`);
  });
}


function checked(id, defaultValue=false) {
  const el = $(id);
  if (!el) return defaultValue;
  return !!el.checked;
}

async function enableCreativeSchedule() {
  let waitSeconds = Number($("creativeWaitSeconds")?.value || 30);
  if (!Number.isFinite(waitSeconds) || waitSeconds < 5) waitSeconds = 30;
  await chrome.storage.local.set({ creativeWaitSeconds: waitSeconds });
  const timesText = $("creativeScheduleTimes")?.value?.trim() || "";
  const intervalMinutes = Number($("creativeScheduleInterval")?.value?.trim() || 0);
  const chatgptMode = $("creativeScheduleMode")?.value || "none";
  const noDuplicate = checked("creativeNoDuplicate", true);
  const sendOnlyImportant = checked("creativeOnlyImportant", true);
  setStatus(`正在开启素材定时监控…等待秒数 ${waitSeconds}，模式 ${chatgptMode}`);
  const res = await chrome.runtime.sendMessage({
    type: "CREATIVE_SCHEDULE_SET_V13",
    config: { timesText, intervalMinutes, chatgptMode, waitAfterOpenMs: Math.max(5, waitSeconds) * 1000, noDuplicate, sendOnlyImportant }
  });
  if (!res.ok) throw new Error(res.error || "开启素材定时失败");
  show(res);
  setStatus(`素材定时已开启：${res.created.length} 个任务。模式：${chatgptMode}；等待 ${waitSeconds} 秒；无变化${noDuplicate ? "不发送" : "仍发送"}；重要变化过滤：${sendOnlyImportant ? "开启" : "关闭"}`);
}

bind("enableCreativeScheduleBtn", async () => {
  try { await enableCreativeSchedule(); }
  catch (e) { setStatus("开启素材定时失败：" + e.message); }
});

bind("disableCreativeScheduleBtn", async () => {
  try {
    const res = await chrome.runtime.sendMessage({ type: "CREATIVE_SCHEDULE_DISABLE_V13" });
    if (!res.ok) throw new Error(res.error || "关闭失败");
    show(res);
    setStatus("素材定时已关闭");
  } catch (e) { setStatus("关闭素材定时失败：" + e.message); }
});

bind("creativeScheduleStatusBtn", async () => {
  try {
    const res = await chrome.runtime.sendMessage({ type: "CREATIVE_SCHEDULE_STATUS_V13" });
    if (!res.ok) throw new Error(res.error || "读取失败");
    show(res);
    const alarms = res.alarms || [];
    const cfg = res.config || {};
    const job = res.currentCreativeImportJob;
    setStatus(`素材定时：${cfg.enabled ? "已开启" : "未开启"}\n已保存素材页：${res.savedCreativeUrl || "未保存"}\n任务数：${alarms.length}\n当前任务：${job ? (job.state || "运行中") : "无"}`);
  } catch (e) { setStatus("读取素材定时状态失败：" + e.message); }
});

bind("creativeLatestSendBtn2", async () => {
  try {
    setStatus("正在发送最新素材消息到 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "OPEN_LATEST_CHATGPT_V10", autoClickSend: true });
    if (!res.ok) throw new Error(res.error || "发送失败");
    show(res);
    setStatus("已尝试发送最新素材消息到 ChatGPT。");
  } catch (e) { setStatus("发送最新素材消息失败：" + e.message); }
});

bind("clearBtn", () => {
  lastData = null;
  lastScreenshot = null;
  $("output").value = "";
  setStatus("已清空");
});

bind("runCommandBtn", async () => {
  try {
    const command = $("command").value.trim();
    setStatus("执行中…");
    const res = await messageContent("RUN_COMMAND_V10", { command });
    show(res);
    setStatus(res.ok ? "执行完成" : "执行失败：" + res.error);
  } catch (e) {
    setStatus("执行失败：" + e.message);
  }
});

bind("capturePasteChatGPTBtn", async () => {
  try {
    setStatus("正在刷新 TikTok 页面，刷新后等待 2 分钟，再采集并填入 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "CAPTURE_AND_CHATGPT_V10", autoClickSend: false, forceSend: true });
    if (!res.ok) throw new Error(res.error || "填入失败");
    show(res);
    setStatus("已采集并填入 ChatGPT 输入框，请确认后手动发送。\n说明：这个按钮是强制测试，不受重复数据限制。");
  } catch (e) {
    setStatus("采集并填入失败：" + e.message);
  }
});

bind("captureSendChatGPTBtn", async () => {
  try {
    setStatus("正在刷新 TikTok 页面，刷新后等待 2 分钟，再采集并自动发送到 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "CAPTURE_AND_CHATGPT_V10", autoClickSend: true, forceSend: true });
    if (!res.ok) throw new Error(res.error || "发送失败");
    show(res);
    setStatus("已采集，并尝试点击 ChatGPT 发送按钮。\n说明：这个按钮是强制测试，不受重复数据限制。");
  } catch (e) {
    setStatus("采集并发送失败：" + e.message);
  }
});

bind("latestPasteChatGPTBtn", async () => {
  try {
    setStatus("正在把最新采集消息填入 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "OPEN_LATEST_CHATGPT_V10", autoClickSend: false });
    if (!res.ok) throw new Error(res.error || "填入失败");
    show(res);
    setStatus("已填入 ChatGPT 输入框，请确认后手动发送。 ");
  } catch (e) {
    setStatus("最新填入失败：" + e.message);
  }
});

bind("latestSendChatGPTBtn", async () => {
  try {
    setStatus("正在把最新采集消息发送到 ChatGPT…");
    const res = await chrome.runtime.sendMessage({ type: "OPEN_LATEST_CHATGPT_V10", autoClickSend: true });
    if (!res.ok) throw new Error(res.error || "发送失败");
    show(res);
    setStatus("已尝试发送最新采集消息到 ChatGPT。 ");
  } catch (e) {
    setStatus("最新发送失败：" + e.message);
  }
});

bind("enableScheduleBtn", async () => {
  try {
    const timesText = $("scheduleTimes").value.trim();
    const intervalMinutes = Number($("scheduleInterval").value.trim() || 0);
    const chatgptMode = $("chatgptMode").value || "none";
    const refreshBeforeCapture = checked("refreshBeforeCapture", true);
    const noDuplicate = checked("noDuplicate", true);
    const sendOnlyImportant = checked("sendOnlyImportant", false);
    const waitAfterRefreshMs = Math.max(0, Number(($("refreshWaitSeconds")?.value || "120")) * 1000);
    const autoPaginate = checked("autoPaginate", true);
    const maxPages = Math.max(1, Number(($("maxPages")?.value || "10")));
    const pageWaitMs = Math.max(1000, Number(($("pageWaitSeconds")?.value || "6")) * 1000);
    const activeOnlyMessage = checked("activeOnlyMessage", true);
    setStatus("正在开启定时…");
    const res = await chrome.runtime.sendMessage({
      type: "SCHEDULE_SET_V10",
      config: { timesText, intervalMinutes, chatgptMode, refreshBeforeCapture, noDuplicate, sendOnlyImportant, waitAfterRefreshMs, autoPaginate, maxPages, pageWaitMs, activeOnlyMessage }
    });
    if (!res.ok) throw new Error(res.error || "开启失败");
    show(res);
    setStatus(`定时已开启：${res.created.length} 个任务。模式：${chatgptMode}。\n数据无变化：${noDuplicate ? "不重复发送" : "仍发送"}；采集前刷新：${refreshBeforeCapture ? "开启" : "关闭"}；刷新等待：${Math.round(waitAfterRefreshMs/1000)}秒；自动翻页：${autoPaginate ? "开启" : "关闭"}；最多${maxPages}页`);
  } catch (e) {
    setStatus("开启定时失败：" + e.message);
  }
});

bind("disableScheduleBtn", async () => {
  try {
    setStatus("正在关闭定时…");
    const res = await chrome.runtime.sendMessage({ type: "SCHEDULE_DISABLE_V10" });
    if (!res.ok) throw new Error(res.error || "关闭失败");
    show(res);
    setStatus("定时已关闭");
  } catch (e) {
    setStatus("关闭定时失败：" + e.message);
  }
});

bind("scheduleStatusBtn", async () => {
  try {
    const res = await chrome.runtime.sendMessage({ type: "SCHEDULE_STATUS_V10" });
    if (!res.ok) throw new Error(res.error || "读取状态失败");
    show(res);
    const last = res.lastAutoResult?.saved;
    setStatus(`定时状态：${res.alarms?.length || 0} 个任务；最新消息：${res.hasLatestMessage ? "有" : "无"}\n上次采集：${last ? (last.should_send ? "有变化/可发送" : "无变化/已拦截") : "暂无"}`);
  } catch (e) {
    setStatus("查看定时状态失败：" + e.message);
  }
});

bind("autoTestBtn", async () => {
  try {
    setStatus("正在立即测试：刷新页面后等待 2 分钟再采集…");
    const res = await chrome.runtime.sendMessage({
      type: "AUTO_CAPTURE_NOW_V10",
      forceSend: false,
      noDuplicate: checked("noDuplicate", true),
      sendOnlyImportant: checked("sendOnlyImportant", false),
      refreshBeforeCapture: checked("refreshBeforeCapture", true),
      waitAfterRefreshMs: Math.max(0, Number(($("refreshWaitSeconds")?.value || "120")) * 1000),
      autoPaginate: checked("autoPaginate", true),
      maxPages: Math.max(1, Number(($("maxPages")?.value || "10"))),
      pageWaitMs: Math.max(1000, Number(($("pageWaitSeconds")?.value || "6")) * 1000),
      activeOnlyMessage: checked("activeOnlyMessage", true)
    });
    if (!res.ok) throw new Error(res.error || "测试采集失败");
    show(res);
    const saved = res.saved || {};
    setStatus(`测试采集成功，已保存到本地：${saved.saved_dir || ""}\n发送判断：${saved.should_send ? "有变化，可发送" : "数据无变化，不发送"}\n原因：${saved.send_reason || ""}`);
  } catch (e) {
    setStatus("测试采集失败：" + e.message);
  }
});

(async function init() {
  try {
    const data = await chrome.storage.local.get(["scheduleConfig", "creativeWaitSeconds", "creativeScheduleConfig"]);
    const cfg = data.scheduleConfig || {};
    if ($("creativeWaitSeconds")) $("creativeWaitSeconds").value = String(data.creativeWaitSeconds || 30);
    const ccfg = data.creativeScheduleConfig || {};
    if ($("creativeScheduleTimes") && ccfg.times && ccfg.times.length) $("creativeScheduleTimes").value = ccfg.times.join(", ");
    if ($("creativeScheduleInterval") && ccfg.intervalMinutes) $("creativeScheduleInterval").value = String(ccfg.intervalMinutes);
    if ($("creativeScheduleMode") && ccfg.chatgptMode) $("creativeScheduleMode").value = ccfg.chatgptMode;
    if ($("creativeNoDuplicate") && typeof ccfg.noDuplicate === "boolean") $("creativeNoDuplicate").checked = ccfg.noDuplicate;
    if ($("creativeOnlyImportant") && typeof ccfg.sendOnlyImportant === "boolean") $("creativeOnlyImportant").checked = ccfg.sendOnlyImportant;
    if (cfg.times && cfg.times.length) $("scheduleTimes").value = cfg.times.join(", ");
    if (cfg.intervalMinutes) $("scheduleInterval").value = String(cfg.intervalMinutes);
    if (cfg.chatgptMode) $("chatgptMode").value = cfg.chatgptMode;
    if (typeof cfg.refreshBeforeCapture === "boolean") $("refreshBeforeCapture").checked = cfg.refreshBeforeCapture;
    if (typeof cfg.noDuplicate === "boolean") $("noDuplicate").checked = cfg.noDuplicate;
    if (typeof cfg.sendOnlyImportant === "boolean") $("sendOnlyImportant").checked = cfg.sendOnlyImportant;
    if (cfg.waitAfterRefreshMs !== undefined && $("refreshWaitSeconds")) $("refreshWaitSeconds").value = String(Math.round(Number(cfg.waitAfterRefreshMs || 120000) / 1000));
    if (typeof cfg.autoPaginate === "boolean" && $("autoPaginate")) $("autoPaginate").checked = cfg.autoPaginate;
    if (cfg.maxPages && $("maxPages")) $("maxPages").value = String(cfg.maxPages);
    if (cfg.pageWaitMs !== undefined && $("pageWaitSeconds")) $("pageWaitSeconds").value = String(Math.round(Number(cfg.pageWaitMs || 6000) / 1000));
    if (typeof cfg.activeOnlyMessage === "boolean" && $("activeOnlyMessage")) $("activeOnlyMessage").checked = cfg.activeOnlyMessage;
  } catch (_) {}
  // 弹窗每次打开都自动检测本地管家，避免显示默认“未连接”误判。
  autoCheckLocalAgent();
})();
