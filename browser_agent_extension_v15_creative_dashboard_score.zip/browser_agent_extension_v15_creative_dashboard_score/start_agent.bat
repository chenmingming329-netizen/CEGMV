@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Starting TikTok GMV Max Ad Manager v1.5 Creative Dashboard Score on http://127.0.0.1:8774 ...
echo Do not close this window.
python local_agent.py
if errorlevel 1 (
  echo.
  echo Python command failed. Trying py local_agent.py ...
  py local_agent.py
)
echo.
echo Process ended. Press any key to close.
pause >nul
