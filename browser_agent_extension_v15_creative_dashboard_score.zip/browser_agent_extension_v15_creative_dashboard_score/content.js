(() => {
  if (window.__browserControlHelperV10Installed) return;
  window.__browserControlHelperV10Installed = true;

  const MAX_ITEMS = 180;
  const VERSION = "1.5.0";

  function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
  }

  function toNumber(value) {
    if (value === null || value === undefined || value === "") return null;
    const n = Number(String(value).replace(/,/g, ""));
    return Number.isFinite(n) ? n : null;
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style && style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }

  function getSelector(el) {
    if (!el || !el.tagName) return "";
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
      let part = node.tagName.toLowerCase();
      if (node.classList && node.classList.length) {
        part += "." + Array.from(node.classList).slice(0, 2).map(c => CSS.escape(c)).join(".");
      }
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(x => x.tagName === node.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      parts.unshift(part);
      node = parent;
    }
    return parts.join(" > ");
  }

  function collectButtons() {
    return Array.from(document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], a'))
      .filter(isVisible)
      .slice(0, MAX_ITEMS)
      .map(el => ({
        text: cleanText(el.innerText || el.value || el.getAttribute('aria-label') || el.title),
        tag: el.tagName.toLowerCase(),
        selector: getSelector(el),
        href: el.href || ""
      }))
      .filter(x => x.text || x.href);
  }

  function collectInputs() {
    return Array.from(document.querySelectorAll('input, textarea, select, [contenteditable="true"]'))
      .filter(isVisible)
      .slice(0, MAX_ITEMS)
      .map(el => ({
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute('type') || "",
        name: el.getAttribute('name') || "",
        placeholder: el.getAttribute('placeholder') || "",
        ariaLabel: el.getAttribute('aria-label') || "",
        selector: getSelector(el),
        value: el.tagName.toLowerCase() === 'select' ? (el.value || "") : ""
      }));
  }

  function collectHeadings() {
    return Array.from(document.querySelectorAll('h1,h2,h3'))
      .filter(isVisible)
      .slice(0, 60)
      .map(el => cleanText(el.innerText))
      .filter(Boolean);
  }

  function collectTables() {
    const rows = Array.from(document.querySelectorAll('tr, [role="row"]'))
      .filter(isVisible)
      .map(el => cleanText(el.innerText))
      .filter(t => t.length > 8)
      .slice(0, 100);
    return Array.from(new Set(rows));
  }

  function parseUsdList(text) {
    const out = [];
    const re = /([0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?)\s*USD/gi;
    let m;
    while ((m = re.exec(text))) out.push(toNumber(m[1]));
    return out.filter(x => x !== null);
  }

  function countCampaignNames(text) {
    return (text.match(/商品\s*GMV\s*Max_[^\s]+/gi) || []).length;
  }

  function getDirectCellTexts(row) {
    let cells = [];
    try {
      cells = Array.from(row.querySelectorAll(':scope > td, :scope > th, :scope > [role="cell"], :scope > [role="gridcell"]'));
    } catch (_) {
      cells = [];
    }
    return cells.filter(isVisible).map(el => cleanText(el.innerText || el.textContent || "")).filter(Boolean);
  }

  function analyzeCampaign(item) {
    const spend = Number(item.costUSD || 0);
    const orders = Number(item.skuOrders || 0);
    const revenue = Number(item.revenueUSD || 0);
    const roi = Number(item.roi || 0);
    const target = item.targetROI === null || item.targetROI === undefined ? null : Number(item.targetROI);

    if (spend <= 0) return "无消耗，暂不判断";
    if (item.status === "已生效" && spend < 3 && orders === 0) return "数据太少，继续观察，不加预算";
    if (spend >= 5 && orders === 0) return "有消耗无订单，建议关停或降预算";
    if (target && roi >= target && orders > 0) return "ROI达标，可保留，小幅加预算";
    if (orders >= 20 && roi >= 3) return "有稳定成交，保留并复盘商品/素材";
    if (spend >= 5 && roi < 1) return "ROI过低，不建议重开";
    if (orders > 0 && roi > 0) return "有成交，继续观察";
    return "继续观察";
  }

  function parseCampaignBlock(rawText, index, selector, cells = []) {
    const t = cleanText(rawText);
    const nameMatch = t.match(/商品\s*GMV\s*Max_[^\s]+/i);
    const campaignName = nameMatch ? cleanText(nameMatch[0]) : "";

    const statusMatch = t.match(/(已暂停|已生效|投放中|启用|暂停|Paused|Active)/i);
    let status = statusMatch ? statusMatch[1] : "未知";
    if (/paused|暂停/i.test(status)) status = "已暂停";
    if (/active|投放中|启用|已生效/i.test(status)) status = "已生效";

    const headMatch = t.match(/(?:已暂停|已生效|投放中|启用|暂停|Paused|Active)\s+([0-9,.]+)\s*USD\s+日预算\s*[:：]\s*([0-9,.]+)\s*USD\s+([0-9,.]+)\s*USD/i);
    const planBudgetUSD = headMatch ? toNumber(headMatch[1]) : null;
    let dailyBudgetUSD = headMatch ? toNumber(headMatch[2]) : null;
    let costUSD = headMatch ? toNumber(headMatch[3]) : null;

    if (dailyBudgetUSD === null) {
      const daily = t.match(/日预算\s*[:：]?\s*([0-9,.]+)\s*USD/i);
      dailyBudgetUSD = daily ? toNumber(daily[1]) : null;
    }
    if (costUSD === null && dailyBudgetUSD !== null) {
      const daily = t.match(/日预算\s*[:：]?\s*[0-9,.]+\s*USD/i);
      if (daily) {
        const afterDaily = t.slice(daily.index + daily[0].length);
        const cost = afterDaily.match(/([0-9,.]+)\s*USD/i);
        costUSD = cost ? toNumber(cost[1]) : null;
      }
    }

    let roiProtection = "未知";
    if (/不符合投资回报率\s*\(ROI\)\s*保障资格/i.test(t)) roiProtection = "不符合ROI保障资格";
    else if (/符合投资回报率\s*\(ROI\)\s*保障资格/i.test(t)) roiProtection = "符合ROI保障资格";

    const suggestionMatch = t.match(/(\d+\s*条建议)/);
    const suggestion = suggestionMatch ? suggestionMatch[1] : "";

    const tail = t.match(/(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+持续投放\s+-\s+([0-9.]+)\s+([0-9,.]+)\s*USD\s+([0-9]+)\s+([0-9,.]+)\s*USD\s+([0-9,.]+)\s*USD\s+([0-9.]+)/);
    const scheduleTime = tail ? tail[1] : ((t.match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/) || [""])[0]);
    const targetROI = tail ? toNumber(tail[2]) : null;
    const netCostUSD = tail ? toNumber(tail[3]) : null;
    const skuOrders = tail ? toNumber(tail[4]) : null;
    const avgOrderCostUSD = tail ? toNumber(tail[5]) : null;
    const revenueUSD = tail ? toNumber(tail[6]) : null;
    const roi = tail ? toNumber(tail[7]) : null;

    const baseBudgetMatches = Array.from(t.matchAll(/基础预算\s*[:：]\s*([0-9,.]+)\s*USD/gi)).map(m => toNumber(m[1]));
    const costBaseBudgetUSD = baseBudgetMatches.length ? baseBudgetMatches[0] : null;
    const protectionBaseMatch = t.match(/基础预算\s*[:：]\s*([0-9.]+)\s*$/i);
    const protectionBaseROI = protectionBaseMatch ? toNumber(protectionBaseMatch[1]) : null;

    const item = {
      index,
      campaignName,
      status,
      planBudgetUSD,
      dailyBudgetUSD,
      costUSD,
      costBaseBudgetUSD,
      roiProtection,
      suggestion,
      scheduleTime,
      targetROI,
      netCostUSD,
      skuOrders,
      avgOrderCostUSD,
      revenueUSD,
      roi,
      protectionBaseROI,
      usdNumbers: parseUsdList(t),
      cells,
      rawText: t.slice(0, 1200),
      selector
    };
    item.diagnosis = analyzeCampaign(item);
    return item;
  }

  function isCleanCampaignRow(text) {
    const t = cleanText(text);
    if (!/商品\s*GMV\s*Max_/i.test(t)) return false;
    if (countCampaignNames(t) !== 1) return false;
    if (!/(已暂停|已生效|投放中|启用|暂停|Paused|Active)/i.test(t)) return false;
    if (!/USD/i.test(t)) return false;
    if (!/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/.test(t)) return false;
    if (/广告计划名称\s*状态\s*广告计划预算/.test(t)) return false;
    return true;
  }

  function collectCampaignRowsFromDom() {
    const rows = [];
    const seen = new Set();
    const selectors = [
      'tr[class*="campaign-table-row"]',
      'tr.core-table-tr',
      'tbody tr',
      '[role="row"]'
    ];
    Array.from(document.querySelectorAll(selectors.join(',')))
      .filter(isVisible)
      .forEach(el => {
        const rect = el.getBoundingClientRect();
        const text = cleanText(el.innerText || el.textContent || "");
        if (!isCleanCampaignRow(text)) return;
        const name = (text.match(/商品\s*GMV\s*Max_[^\s]+/i) || [""])[0];
        if (!name || seen.has(name)) return;
        seen.add(name);
        rows.push({
          text,
          cells: getDirectCellTexts(el),
          selector: getSelector(el),
          top: Math.round(rect.top),
          height: Math.round(rect.height),
          source: "dom_row"
        });
      });
    rows.sort((a, b) => a.top - b.top);
    return rows;
  }

  function collectCampaignRowsFromPageText() {
    const pageText = cleanText(document.body ? document.body.innerText : "");
    const nameRe = /商品\s*GMV\s*Max_[^\s]+/gi;
    const matches = Array.from(pageText.matchAll(nameRe));
    const rows = [];
    const seen = new Set();
    for (let i = 0; i < matches.length; i++) {
      const start = matches[i].index;
      const end = i + 1 < matches.length ? matches[i + 1].index : Math.min(pageText.length, start + 1200);
      const block = cleanText(pageText.slice(start, end));
      const name = matches[i][0];
      if (seen.has(name)) continue;
      if (!isCleanCampaignRow(block)) continue;
      seen.add(name);
      rows.push({ text: block, cells: [], selector: "pageText", top: i, height: 0, source: "page_text" });
    }
    return rows;
  }

  function collectGmvMax() {
    let sourceRows = collectCampaignRowsFromDom();
    if (!sourceRows.length) sourceRows = collectCampaignRowsFromPageText();

    const campaigns = sourceRows.slice(0, 100).map((x, i) => {
      const parsed = parseCampaignBlock(x.text, i + 1, x.selector, x.cells);
      parsed.source = x.source;
      return parsed;
    });

    const totalSpendUSD = campaigns.reduce((s, x) => s + (Number(x.costUSD) || 0), 0);
    const totalRevenueUSD = campaigns.reduce((s, x) => s + (Number(x.revenueUSD) || 0), 0);
    const totalOrders = campaigns.reduce((s, x) => s + (Number(x.skuOrders) || 0), 0);
    const activeCount = campaigns.filter(x => x.status === "已生效").length;
    const pausedCount = campaigns.filter(x => x.status === "已暂停").length;
    const visibleBudgetUSD = campaigns.reduce((s, x) => s + (Number(x.dailyBudgetUSD) || 0), 0);

    const summary = {
      totalCampaigns: campaigns.length,
      activeCount,
      pausedCount,
      totalSpendUSD: Math.round(totalSpendUSD * 100) / 100,
      totalRevenueUSD: Math.round(totalRevenueUSD * 100) / 100,
      totalOrders,
      overallROI: totalSpendUSD > 0 ? Math.round((totalRevenueUSD / totalSpendUSD) * 100) / 100 : 0,
      visibleBudgetUSD: Math.round(visibleBudgetUSD * 100) / 100,
      source: sourceRows.length ? sourceRows[0].source : "none"
    };

    return { version: VERSION, summary, campaigns, items: campaigns };
  }



  // v1.3.1 素材/Creative 页面强识别采集：专门适配“广告计划数据分析 > 创意素材”横向表格。
  function parsePercent(text) {
    const m = String(text || '').match(/([0-9]+(?:\.[0-9]+)?)\s*%/);
    return m ? toNumber(m[1]) : null;
  }

  function firstNumber(text) {
    const m = String(text || '').replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : null;
  }

  function parseNumberish(text) {
    const t = String(text || '').trim();
    if (!t || /^[-–—]$/.test(t) || /^N\/A$/i.test(t)) return null;
    const usd = parseUsdList(t);
    if (usd.length) return usd[0];
    const pct = parsePercent(t);
    if (pct !== null) return pct;
    return firstNumber(t);
  }

  function looksLikeHeaderText(t) {
    return /(素材|创意|作品\s*ID|TikTok\s*账号|授权类型|状态|发布时间|Creative|Ad name|名称|消耗|花费|Spend|Cost|成本|展示|Impressions|曝光|点击|Clicks|CTR|点击率|订单|Orders|SKU|成交|收入|Revenue|GMV|ROI|ROAS|投资回报|转化|CPA|播放|Views|完播)/i.test(t || '');
  }

  function getCellTextsDeep(row) {
    let cells = [];
    try { cells = Array.from(row.querySelectorAll(':scope > td, :scope > th, :scope > [role="cell"], :scope > [role="gridcell"]')); } catch (_) { cells = []; }
    if (!cells.length) {
      cells = Array.from(row.querySelectorAll('td, th, [role="cell"], [role="gridcell"], [class*="cell"], [class*="Cell"]'));
    }
    const out = [];
    const seen = new Set();
    for (const c of cells.filter(isVisible)) {
      const txt = cleanText(c.innerText || c.textContent || '');
      if (!txt) continue;
      const rect = c.getBoundingClientRect();
      const key = `${Math.round(rect.left)}|${Math.round(rect.top)}|${txt}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ text: txt, left: Math.round(rect.left), top: Math.round(rect.top), width: Math.round(rect.width), selector: getSelector(c) });
    }
    out.sort((a, b) => a.left - b.left || a.top - b.top);
    return out.map(x => x.text);
  }

  function findCreativeRoot() {
    const candidates = Array.from(document.querySelectorAll('section, main, div, [role="tabpanel"], [class*="pane"], [class*="Panel"], [class*="table"], [class*="Table"]'))
      .filter(isVisible)
      .map(el => {
        const text = cleanText(el.innerText || el.textContent || '');
        let score = 0;
        if (/创意素材/.test(text)) score += 40;
        if (/作品\s*ID/.test(text)) score += 40;
        if (/TikTok\s*账号/.test(text)) score += 25;
        if (/授权类型/.test(text)) score += 20;
        if (/SKU\s*订单数|总收入|投资回报率|ROI/.test(text)) score += 15;
        if (/广告计划名称\s*状态\s*广告计划预算/.test(text)) score -= 60;
        if (/商品\s*GMV\s*Max_/.test(text) && !/作品\s*ID/.test(text)) score -= 30;
        const rect = el.getBoundingClientRect();
        return { el, text, score, area: rect.width * rect.height, len: text.length };
      })
      .filter(x => x.score > 0);
    candidates.sort((a, b) => (b.score - a.score) || (a.area - b.area));
    return candidates[0]?.el || document.body;
  }

  function getScrollableWithin(root) {
    const els = [root, ...Array.from(root.querySelectorAll('*'))].filter(el => el instanceof Element && isVisible(el));
    const horizontal = els.filter(el => el.scrollWidth > el.clientWidth + 30)
      .sort((a, b) => (b.scrollWidth - b.clientWidth) - (a.scrollWidth - a.clientWidth));
    const vertical = els.filter(el => el.scrollHeight > el.clientHeight + 80)
      .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));
    return { horizontal: horizontal[0] || null, vertical: vertical[0] || null };
  }

  function getRowsWithCellsFromRoot(root) {
    const rowEls = Array.from(root.querySelectorAll('tr, [role="row"], .arco-table-tr, [class*="table-row"], [class*="TableRow"]'))
      .filter(isVisible);
    const rows = [];
    const seen = new Set();
    for (const el of rowEls) {
      const cells = getCellTextsDeep(el);
      const text = cleanText(el.innerText || el.textContent || '');
      if (!text || text.length < 4) continue;
      if (cells.length < 2 && !/创意素材|作品\s*ID/.test(text)) continue;
      const rect = el.getBoundingClientRect();
      const key = `${Math.round(rect.top)}|${cells.join('|') || text}`;
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({ text, cells, selector: getSelector(el), top: Math.round(rect.top), source: 'creative_strong_table' });
    }
    rows.sort((a, b) => a.top - b.top);
    return rows.slice(0, 300);
  }

  function isCreativeHeaderCells(cells) {
    const t = (cells || []).join('|');
    return /创意素材/.test(t) && /作品\s*ID/.test(t) && /TikTok\s*账号/.test(t);
  }

  function mergeHeader(headers, cells) {
    const out = headers.slice();
    for (const c of cells || []) {
      if (looksLikeHeaderText(c) && !out.includes(c)) out.push(c);
    }
    return out;
  }

  function keyForCreativeRow(cells, rowText, fallback) {
    const id = (rowText.match(/\b\d{12,22}\b/) || [''])[0];
    if (id) return `id:${id}`;
    const name = (cells || []).find(c => c && !looksLikeHeaderText(c) && !/^\d+(?:\.\d+)?\s*(USD|%)?$/i.test(c) && !/^N\/A$/i.test(c));
    return `row:${fallback}:${name || cleanText(rowText).slice(0, 60)}`;
  }

  function mergeRowCells(oldCells, newCells) {
    const out = (oldCells || []).slice();
    for (const c of newCells || []) {
      if (!c || out.includes(c)) continue;
      out.push(c);
    }
    return out;
  }

  async function collectCreativeDataFull(options = {}) {
    const root = findCreativeRoot();
    const { horizontal, vertical } = getScrollableWithin(root);
    const hMax = horizontal ? Math.max(0, horizontal.scrollWidth - horizontal.clientWidth) : 0;
    const positions = hMax > 30 ? [0, Math.floor(hMax * 0.5), hMax] : [0];
    const rowMap = new Map();
    let headers = [];

    for (const pos of positions) {
      if (horizontal) {
        horizontal.scrollLeft = pos;
        horizontal.dispatchEvent(new Event('scroll', { bubbles: true }));
        await new Promise(r => setTimeout(r, Number(options.scrollWaitMs || 900)));
      }
      const rows = getRowsWithCellsFromRoot(root);
      for (const r of rows) {
        if (isCreativeHeaderCells(r.cells) || (r.cells || []).filter(looksLikeHeaderText).length >= 3) {
          headers = mergeHeader(headers, r.cells);
          continue;
        }
        const text = r.text || '';
        if (/广告计划名称\s*状态\s*广告计划预算/.test(text)) continue;
        if (/商品\s*GMV\s*Max_/.test(text)) continue;
        if (!/\b\d{12,22}\b|商品卡片|#|学习中|投放中|联盟|商业中心|TikTok Shop|USD/i.test(text)) continue;
        const key = keyForCreativeRow(r.cells, text, r.top);
        const existing = rowMap.get(key);
        if (existing) {
          existing.cells = mergeRowCells(existing.cells, r.cells);
          existing.rawText = cleanText((existing.rawText || '') + ' ' + text).slice(0, 2500);
        } else {
          rowMap.set(key, { ...r, rawText: text, mergeKey: key });
        }
      }
    }

    // 尝试纵向滚动加载更多，仅采集左侧可见基础列，避免过度复杂。默认滚动 3 屏。
    const maxV = vertical ? Math.max(0, vertical.scrollHeight - vertical.clientHeight) : 0;
    const vSteps = maxV > 100 ? [0, Math.floor(maxV * 0.33), Math.floor(maxV * 0.66), maxV] : [];
    if (vertical && vSteps.length) {
      if (horizontal) horizontal.scrollLeft = 0;
      for (const v of vSteps) {
        vertical.scrollTop = v;
        vertical.dispatchEvent(new Event('scroll', { bubbles: true }));
        await new Promise(r => setTimeout(r, Number(options.scrollWaitMs || 900)));
        const rows = getRowsWithCellsFromRoot(root);
        for (const r of rows) {
          if (isCreativeHeaderCells(r.cells) || (r.cells || []).filter(looksLikeHeaderText).length >= 3) {
            headers = mergeHeader(headers, r.cells);
            continue;
          }
          const text = r.text || '';
          if (/广告计划名称\s*状态\s*广告计划预算/.test(text) || /商品\s*GMV\s*Max_/.test(text)) continue;
          if (!/\b\d{12,22}\b|商品卡片|#|学习中|投放中|联盟|商业中心|TikTok Shop|USD/i.test(text)) continue;
          const key = keyForCreativeRow(r.cells, text, r.top);
          const existing = rowMap.get(key);
          if (existing) {
            existing.cells = mergeRowCells(existing.cells, r.cells);
            existing.rawText = cleanText((existing.rawText || '') + ' ' + text).slice(0, 2500);
          } else rowMap.set(key, { ...r, rawText: text, mergeKey: key });
        }
      }
    }

    const rows = Array.from(rowMap.values()).slice(0, 200);
    const items = rows.map((r, i) => parseCreativeRowStrong(r, i + 1, headers));
    const recognized = {
      creativeName: items.some(x => x.creativeName),
      workId: items.some(x => x.workId),
      spendUSD: items.some(x => x.spendUSD !== null && x.spendUSD !== undefined),
      clicks: items.some(x => x.clicks !== null && x.clicks !== undefined),
      ctr: items.some(x => x.ctr !== null && x.ctr !== undefined),
      orders: items.some(x => x.orders !== null && x.orders !== undefined),
      revenueUSD: items.some(x => x.revenueUSD !== null && x.revenueUSD !== undefined),
      roi: items.some(x => x.roi !== null && x.roi !== undefined),
      views: items.some(x => x.views !== null && x.views !== undefined),
      completionRate: items.some(x => x.completionRate !== null && x.completionRate !== undefined)
    };
    return {
      version: '1.5.0',
      pageKind: 'creative_strong_table',
      url: location.href,
      title: document.title,
      headers,
      rowCount: items.length,
      recognized,
      items,
      rawRows: rows.slice(0, 30),
      scrollInfo: { horizontal: !!horizontal, vertical: !!vertical, horizontalMax: hMax, verticalMax: maxV, horizontalPositions: positions }
    };
  }

  function findMetricByHeader(cells, headers, patterns) {
    if (!headers || !headers.length) return '';
    for (let i = 0; i < headers.length; i++) {
      const h = headers[i] || '';
      if (patterns.some(re => re.test(h))) {
        // 按当前可见顺序取同位置；如果行包含更多合并列，依然尽量命中。
        if (i < cells.length) return cells[i];
      }
    }
    return '';
  }

  function parseCreativeRowStrong(row, index, headers) {
    const cells = (row.cells || []).map(cleanText).filter(Boolean);
    const text = row.rawText || row.text || cells.join(' ');
    const workId = (text.match(/\b\d{12,22}\b/) || [''])[0];
    let creativeName = cells[0] || '';
    if (/^开\/关$|^创意素材$|^作品\s*ID$/i.test(creativeName)) creativeName = '';
    if (!creativeName || /^\d{12,22}$/.test(creativeName)) {
      creativeName = (cells.find(c => c && !/^\d{12,22}$/.test(c) && !looksLikeHeaderText(c) && !/^N\/A$/i.test(c) && !/^\d+(?:\.\d+)?\s*(USD|%)?$/i.test(c)) || '').slice(0, 300);
    }
    if (/商品卡片/i.test(text)) creativeName = creativeName || '商品卡片';

    const status = (cells.find(c => /学习中|投放中|排队中|建议授权|正在加热|已加热|可用|暂停|审核|Active|Paused|Learning/i.test(c)) || '') || ((text.match(/(学习中|投放中|排队中|建议授权|正在加热|已加热|可用|暂停|审核中|Active|Paused|Learning)/i) || [''])[0]);
    const account = cells.find(c => /^@/.test(c) || /zhuzhutao|phoneHD|TikTok Shop/i.test(c)) || '';
    const authType = cells.find(c => /联盟批量授权|商业中心|TikTok Shop|官方账号|授权/i.test(c)) || '';
    const publishTime = (text.match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}/) || [''])[0];

    const usdValues = parseUsdList(text);
    let spendUSD = null, revenueUSD = null, cpaUSD = null;
    // 优先按“成本”列或 USD 顺序解析，创意表第一个 USD 基本是成本，后面依次可能是平均下单成本、总收入。
    const spendByHeader = findMetricByHeader(cells, headers, [/成本|消耗|花费|Spend|Cost/i]);
    if (spendByHeader) spendUSD = parseNumberish(spendByHeader);
    if (spendUSD === null) spendUSD = usdValues[0] ?? null;

    const cpaByHeader = findMetricByHeader(cells, headers, [/平均下单成本|转化成本|CPA|下单成本/i]);
    if (cpaByHeader) cpaUSD = parseNumberish(cpaByHeader);

    const revByHeader = findMetricByHeader(cells, headers, [/总收入|成交|收入|Revenue|GMV|Sales/i]);
    if (revByHeader) revenueUSD = parseNumberish(revByHeader);
    if (revenueUSD === null && usdValues.length >= 2) revenueUSD = usdValues[usdValues.length - 1];

    // 从已知表格顺序辅助解析：0素材 1ID 2账号 3授权 4状态 5时间 6成本 7订单 8CPA 9收入 10ROI 11曝光 12点击 13CTR ...
    const orderByIdx = parseNumberish(cells[7]);
    const revenueByIdx = parseNumberish(cells[9]);
    const roiByIdx = parseNumberish(cells[10]);
    const imprByIdx = parseNumberish(cells[11]);
    const clickByIdx = parseNumberish(cells[12]);
    const ctrByIdx = parsePercent(cells[13]) ?? parseNumberish(cells[13]);

    const ordersByHeader = findMetricByHeader(cells, headers, [/SKU\s*订单|订单|Orders/i]);
    const roiByHeader = findMetricByHeader(cells, headers, [/ROI|ROAS|投资回报/i]);
    const impByHeader = findMetricByHeader(cells, headers, [/曝光|展示|Impressions/i]);
    const clickByHeader = findMetricByHeader(cells, headers, [/点击数|商品广告点击数|Clicks/i]);
    const ctrByHeader = findMetricByHeader(cells, headers, [/点击率|CTR/i]);
    const completionByHeader = findMetricByHeader(cells, headers, [/完播率|Completion/i]);
    const viewsByHeader = findMetricByHeader(cells, headers, [/播放量|播放数|Views/i]);

    const item = {
      index,
      creativeName,
      workId,
      account,
      authType,
      status,
      publishTime,
      spendUSD,
      impressions: parseNumberish(impByHeader) ?? imprByIdx,
      clicks: parseNumberish(clickByHeader) ?? clickByIdx,
      ctr: (parsePercent(ctrByHeader) ?? parseNumberish(ctrByHeader) ?? ctrByIdx),
      orders: (parseNumberish(ordersByHeader) ?? orderByIdx),
      revenueUSD: revenueUSD ?? revenueByIdx,
      roi: (parseNumberish(roiByHeader) ?? roiByIdx),
      cpaUSD,
      views: parseNumberish(viewsByHeader),
      completionRate: parsePercent(completionByHeader) ?? parseNumberish(completionByHeader),
      cells,
      rawText: text.slice(0, 2500),
      selector: row.selector,
      source: row.source || 'creative_strong_table',
      mergeKey: row.mergeKey || ''
    };
    return item;
  }

  function collectCreativeData() {
    // 保留旧接口，但默认使用强识别同步可见数据；完整横向读取请调用 GET_CREATIVE_FULL_V121。
    const root = findCreativeRoot();
    const rows = getRowsWithCellsFromRoot(root);
    let headers = [];
    const dataRows = [];
    for (const r of rows) {
      if (isCreativeHeaderCells(r.cells) || (r.cells || []).filter(looksLikeHeaderText).length >= 3) { headers = mergeHeader(headers, r.cells); continue; }
      const text = r.text || '';
      if (/广告计划名称\s*状态\s*广告计划预算/.test(text) || /商品\s*GMV\s*Max_/.test(text)) continue;
      if (/\b\d{12,22}\b|商品卡片|#|学习中|投放中|联盟|商业中心|TikTok Shop|USD/i.test(text)) dataRows.push(r);
    }
    const items = dataRows.slice(0, 120).map((r, i) => parseCreativeRowStrong(r, i + 1, headers));
    const recognized = {
      creativeName: items.some(x => x.creativeName), workId: items.some(x => x.workId),
      spendUSD: items.some(x => x.spendUSD !== null && x.spendUSD !== undefined), clicks: items.some(x => x.clicks !== null && x.clicks !== undefined),
      ctr: items.some(x => x.ctr !== null && x.ctr !== undefined), orders: items.some(x => x.orders !== null && x.orders !== undefined),
      revenueUSD: items.some(x => x.revenueUSD !== null && x.revenueUSD !== undefined), roi: items.some(x => x.roi !== null && x.roi !== undefined),
      views: items.some(x => x.views !== null && x.views !== undefined), completionRate: items.some(x => x.completionRate !== null && x.completionRate !== undefined)
    };
    return { version: '1.5.0', pageKind: 'creative_strong_table', url: location.href, title: document.title, headers, rowCount: items.length, recognized, items, rawRows: dataRows.slice(0, 30) };
  }

  function collectPageSnapshot() {
    const pageText = cleanText(document.body ? document.body.innerText : "").slice(0, 25000);
    const gmv = collectGmvMax();
    return {
      capturedAt: new Date().toISOString(),
      version: VERSION,
      url: location.href,
      title: document.title,
      pageKind: /gmv[-_/]?max/i.test(location.href) || /GMV\s*Max/i.test(document.title) ? 'gmv_max' : 'unknown',
      isGmvMaxPage: /gmv[-_/]?max/i.test(location.href) || /GMV\s*Max/i.test(document.title) || /商品\s*GMV\s*Max_/i.test(document.body ? document.body.innerText : ''),
      headings: collectHeadings(),
      buttons: collectButtons(),
      inputs: collectInputs(),
      tables: collectTables(),
      gmv,
      creative: collectCreativeData(),
      pagination: getPaginationInfo(),
      pageText
    };
  }

  function findClickableByText(text) {
    const needle = text.toLowerCase().trim();
    const candidates = Array.from(document.querySelectorAll('button, [role="button"], a, input[type="button"], input[type="submit"], div, span'))
      .filter(isVisible);
    return candidates.find(el => cleanText(el.innerText || el.value || el.getAttribute('aria-label') || el.title).toLowerCase().includes(needle));
  }



  function findNextPageButton() {
    const candidates = Array.from(document.querySelectorAll('button, [role="button"], a'))
      .filter(isVisible);
    const scored = [];
    for (const el of candidates) {
      const label = cleanText(el.innerText || el.getAttribute('aria-label') || el.title || el.getAttribute('data-testid') || '');
      const cls = String(el.className || '');
      const ariaDisabled = el.getAttribute('aria-disabled') === 'true';
      const disabled = !!el.disabled || ariaDisabled || /disabled/i.test(cls);
      if (disabled) continue;
      let score = 0;
      if (/下一页|下页|下一|Next|next|Page Next|next page/i.test(label)) score += 100;
      if (/right|next|arrow/i.test(cls)) score += 20;
      if (el.querySelector('svg')) score += 5;
      // TikTok/Arco pagination often uses arrow buttons with no text; prefer buttons near page-size / pagination area.
      const rect = el.getBoundingClientRect();
      if (rect.top > window.innerHeight * 0.45) score += 3;
      if (score > 0) scored.push({ el, score, label, selector: getSelector(el) });
    }
    scored.sort((a,b) => b.score - a.score);
    return scored[0] || null;
  }

  function getPaginationInfo() {
    const next = findNextPageButton();
    const pageText = cleanText(document.body ? document.body.innerText : '');
    const currentMatch = pageText.match(/(?:第\s*)?(\d+)\s*(?:\/|of|共)\s*(\d+)/i);
    return {
      hasNext: Boolean(next),
      nextLabel: next ? next.label : '',
      nextSelector: next ? next.selector : '',
      pageTextHint: currentMatch ? `${currentMatch[1]}/${currentMatch[2]}` : ''
    };
  }

  function clickNextPage() {
    const next = findNextPageButton();
    if (!next) return { ok: false, hasNext: false, error: '没有找到可点击的下一页按钮' };
    clickElement(next.el);
    return { ok: true, hasNext: true, clicked: true, label: next.label, selector: next.selector };
  }

  function clickElement(el) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    el.click();
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  }

  function setValue(el, value) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.focus();
    if (el.isContentEditable) el.textContent = value;
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function runCommand(command) {
    const raw = (command || "").trim();
    const lower = raw.toLowerCase();
    if (!raw) return { ok: false, error: "命令为空" };

    if (["extract", "读取", "read"].includes(lower)) {
      return { ok: true, action: "extract", snapshot: collectPageSnapshot() };
    }
    if (["gmv", "读取gmv", "提取gmv", "gmv max"].includes(lower)) {
      return { ok: true, action: "gmv", gmv: collectGmvMax(), url: location.href, title: document.title, capturedAt: new Date().toISOString() };
    }
    if (lower.startsWith("goto ") || lower.startsWith("打开 ")) {
      const url = raw.replace(/^(goto|打开)\s+/i, "").trim();
      location.href = url;
      return { ok: true, action: "goto", url };
    }
    if (lower === "scroll down" || lower === "下滑") {
      window.scrollBy({ top: Math.round(window.innerHeight * 0.8), behavior: "smooth" });
      return { ok: true, action: "scroll_down" };
    }
    if (lower === "scroll up" || lower === "上滑") {
      window.scrollBy({ top: -Math.round(window.innerHeight * 0.8), behavior: "smooth" });
      return { ok: true, action: "scroll_up" };
    }
    if (lower === "scroll top" || lower === "到顶部") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return { ok: true, action: "scroll_top" };
    }
    if (lower === "scroll bottom" || lower === "到底部") {
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
      return { ok: true, action: "scroll_bottom" };
    }
    if (lower.startsWith("clickcss ")) {
      const selector = raw.replace(/^clickcss\s+/i, "").trim();
      const el = document.querySelector(selector);
      if (!el) return { ok: false, error: `找不到 CSS 选择器：${selector}` };
      clickElement(el);
      return { ok: true, action: "clickcss", selector };
    }
    if (lower.startsWith("click ") || lower.startsWith("点击 ")) {
      const text = raw.replace(/^(click|点击)\s+/i, "").trim();
      const el = findClickableByText(text);
      if (!el) return { ok: false, error: `找不到包含文字的按钮/链接：${text}` };
      clickElement(el);
      return { ok: true, action: "click_text", text, selector: getSelector(el) };
    }
    if (lower.startsWith("fill ") || lower.startsWith("输入 ")) {
      const body = raw.replace(/^(fill|输入)\s+/i, "");
      const splitIndex = body.indexOf(" ");
      if (splitIndex === -1) return { ok: false, error: "格式：fill CSS选择器 内容" };
      const selector = body.slice(0, splitIndex).trim();
      const value = body.slice(splitIndex + 1);
      const el = document.querySelector(selector);
      if (!el) return { ok: false, error: `找不到输入框：${selector}` };
      setValue(el, value);
      return { ok: true, action: "fill", selector, valueLength: value.length };
    }

    return { ok: false, error: "未知命令。支持：gmv、extract、click 文字、clickcss 选择器、fill 选择器 内容、goto URL、scroll down/up/top/bottom" };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.type === "PING_V10") {
        sendResponse({ ok: true, version: VERSION });
        return true;
      }
      if (message.type === "GET_SNAPSHOT_V10") {
        sendResponse({ ok: true, version: VERSION, snapshot: collectPageSnapshot() });
        return true;
      }
      if (message.type === "GET_GMV_V10") {
        sendResponse({ ok: true, version: VERSION, gmv: collectGmvMax(), url: location.href, title: document.title, capturedAt: new Date().toISOString() });
        return true;
      }
      if (message.type === "GET_CREATIVE_V11") {
        sendResponse({ ok: true, version: VERSION, creative: collectCreativeData(), snapshot: collectPageSnapshot(), url: location.href, title: document.title, capturedAt: new Date().toISOString() });
        return true;
      }
      if (message.type === "GET_CREATIVE_FULL_V121") {
        (async () => {
          const creative = await collectCreativeDataFull(message.options || {});
          const snapshot = collectPageSnapshot();
          snapshot.creative = creative;
          sendResponse({ ok: true, version: VERSION, creative, snapshot, url: location.href, title: document.title, capturedAt: new Date().toISOString() });
        })().catch(error => sendResponse({ ok: false, version: VERSION, error: error.message || String(error) }));
        return true;
      }
      if (message.type === "RUN_COMMAND_V10") {
        sendResponse({ version: VERSION, ...runCommand(message.command) });
        return true;
      }
      if (message.type === "GET_PAGINATION_V10") {
        sendResponse({ ok: true, version: VERSION, pagination: getPaginationInfo() });
        return true;
      }
      if (message.type === "CLICK_NEXT_PAGE_V10") {
        sendResponse({ version: VERSION, ...clickNextPage() });
        return true;
      }
    } catch (error) {
      sendResponse({ ok: false, version: VERSION, error: error.message || String(error) });
      return true;
    }
  });
})();

// ChatGPT 页面自动填入/发送助手。和 TikTok 采集逻辑分开，避免互相影响。
(() => {
  if (window.__browserControlChatGPTHelperV10Installed) return;
  window.__browserControlChatGPTHelperV10Installed = true;
  const VERSION = "1.5.0";

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style && style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function findComposer() {
    const selectors = [
      '#prompt-textarea',
      'textarea[data-testid="prompt-textarea"]',
      'div[contenteditable="true"][id="prompt-textarea"]',
      'div[contenteditable="true"][data-placeholder]',
      'textarea[placeholder*="Message"]',
      'textarea[placeholder*="Ask"]',
      'textarea[placeholder*="发送"]',
      'textarea',
      'div[contenteditable="true"]'
    ];
    const candidates = [];
    for (const sel of selectors) {
      try { candidates.push(...Array.from(document.querySelectorAll(sel))); } catch (_) {}
    }
    const unique = Array.from(new Set(candidates)).filter(isVisible);
    unique.sort((a, b) => {
      const score = (el) => {
        let s = 0;
        if (el.id === 'prompt-textarea') s += 100;
        if (el.getAttribute('data-testid') === 'prompt-textarea') s += 80;
        if (el.isContentEditable) s += 20;
        if (el.tagName.toLowerCase() === 'textarea') s += 10;
        return -s;
      };
      return score(a) - score(b);
    });
    return unique[0] || null;
  }

  function setNativeValue(el, value) {
    const tag = el.tagName.toLowerCase();
    const proto = tag === 'textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(el, value);
    else el.value = value;
  }

  async function setComposerText(text) {
    const el = findComposer();
    if (!el) throw new Error('找不到 ChatGPT 输入框。请确认已经打开 ChatGPT 对话页面，并且没有被登录/验证页面挡住。');
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await wait(200);
    el.focus();
    await wait(150);

    if (el.tagName.toLowerCase() === 'textarea' || el.tagName.toLowerCase() === 'input') {
      setNativeValue(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable) {
      // 优先模拟真实输入，React/ProseMirror 更容易识别。
      try {
        const range = document.createRange();
        range.selectNodeContents(el);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('delete', false, null);
        document.execCommand('insertText', false, text);
      } catch (_) {
        el.textContent = text;
      }
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      throw new Error('找到的输入框类型不支持自动填入');
    }
    await wait(700);
    return true;
  }

  function findSendButton() {
    const selectors = [
      'button[data-testid="send-button"]',
      '[data-testid="send-button"] button',
      'button[aria-label="Send prompt"]',
      'button[aria-label*="Send prompt"]',
      'button[aria-label*="Send message"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="send"]',
      'button[aria-label*="发送"]',
      'button[aria-label*="提交"]',
      'button[type="submit"]'
    ];
    const usable = (b) => b && isVisible(b) && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
    for (const sel of selectors) {
      let btns = [];
      try { btns = Array.from(document.querySelectorAll(sel)).filter(usable); } catch (_) {}
      if (btns.length) return btns[0];
    }

    const composer = findComposer();
    if (composer) {
      const form = composer.closest('form');
      if (form) {
        const btns = Array.from(form.querySelectorAll('button')).filter(usable);
        const byLabel = btns.find(b => /send|发送|提交/i.test((b.innerText || b.getAttribute('aria-label') || b.title || '').trim()));
        if (byLabel) return byLabel;
        if (btns.length) return btns[btns.length - 1];
      }
    }

    const buttons = Array.from(document.querySelectorAll('button')).filter(usable);
    return buttons.find(b => /send|发送|提交/i.test((b.innerText || b.getAttribute('aria-label') || b.title || '').trim())) || null;
  }

  function clickButton(btn) {
    btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
    btn.focus && btn.focus();
    btn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerType: 'mouse' }));
    btn.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
    btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    btn.click();
    btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    btn.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'mouse' }));
  }

  async function sendToChatGPT(text, autoClickSend) {
    if (!/chatgpt\.com|chat\.openai\.com/i.test(location.href)) {
      throw new Error('当前页面不是 ChatGPT 页面');
    }
    if (!text || !text.trim()) throw new Error('发送文本为空');
    await setComposerText(text);
    if (!autoClickSend) {
      return { ok: true, version: VERSION, action: 'pasted_only', sent: false, textLength: text.length, note: '已填入 ChatGPT 输入框，未自动点击发送。' };
    }
    let btn = null;
    for (let i = 0; i < 10; i++) {
      btn = findSendButton();
      if (btn) break;
      await wait(400);
    }
    if (!btn) throw new Error('文本已填入，但找不到可点击的发送按钮。请手动点发送。');
    clickButton(btn);
    await wait(1200);
    return { ok: true, version: VERSION, action: 'sent', sent: true, textLength: text.length, buttonText: (btn.innerText || btn.getAttribute('aria-label') || btn.title || '').trim(), note: '已尝试点击 ChatGPT 发送按钮。' };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      if (message.type === 'PING_CHATGPT_V10') {
        return { ok: true, version: VERSION, page: 'chatgpt', url: location.href, hasComposer: Boolean(findComposer()) };
      }
      if (message.type === 'SEND_TO_CHATGPT_V10') {
        return await sendToChatGPT(message.text || '', !!message.autoClickSend);
      }
      return null;
    })().then(res => {
      if (res) sendResponse(res);
    }).catch(e => sendResponse({ ok: false, version: VERSION, error: e.message || String(e) }));
    return true;
  });
})();
