@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo TikTok GMV Max Ad Manager Watchdog v1.3
echo It checks http://127.0.0.1:8774/health every 60 seconds.
echo Do not close this window.
:loop
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:8774/health -TimeoutSec 3; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }"
if errorlevel 1 (
  echo [%date% %time%] local_agent not running, starting...
  start "GMV Max Ad Manager" /min cmd /c "cd /d %~dp0 && python local_agent.py"
) else (
  echo [%date% %time%] local_agent OK.
)
timeout /t 60 /nobreak >nul
goto loop
