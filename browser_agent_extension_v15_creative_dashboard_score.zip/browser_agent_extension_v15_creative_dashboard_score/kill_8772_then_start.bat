@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8774 ^| findstr LISTENING') do taskkill /PID %%a /F
cd /d "%~dp0"
python local_agent.py
pause
