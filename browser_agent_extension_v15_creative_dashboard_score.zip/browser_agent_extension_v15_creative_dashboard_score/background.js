const LOCAL_URLS = ["http://127.0.0.1:8774", "http://localhost:8774"];
let LOCAL_URL = LOCAL_URLS[0];
const VERSION = "1.5.0";

async function localFetch(path, options = {}) {
  let lastErr = null;
  for (const base of LOCAL_URLS) {
    try {
      const resp = await fetch(`${base}${path}`, { cache: "no-store", ...options });
      LOCAL_URL = base;
      return resp;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("无法连接本地管家");
}
const ALARM_PREFIX = "GMV_SCHEDULE_V10_";
const JOB_ALARM_PREFIX = "GMV_JOB_CONTINUE_V101_";
const CREATIVE_JOB_ALARM_PREFIX = "CREATIVE_IMPORT_JOB_V114_";
const CREATIVE_REFRESH_JOB_ALARM_PREFIX = "CREATIVE_REFRESH_JOB_V122_";
const CREATIVE_SCHEDULE_ALARM_PREFIX = "CREATIVE_SCHEDULE_V13_";

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function readJsonResponse(resp) {
  const text = await resp.text();
  let json;
  try { json = JSON.parse(text); }
  catch (e) { throw new Error(`本地管家没有返回 JSON，HTTP ${resp.status}，返回内容：${text.slice(0, 180)}`); }
  if (!resp.ok) throw new Error(json.error || `HTTP ${resp.status}`);
  return json;
}

function getDelayMinutesForTime(hhmm) {
  const m = String(hhmm || "").trim().match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  const hour = Number(m[1]);
  const minute = Number(m[2]);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  const now = new Date();
  const target = new Date(now);
  target.setHours(hour, minute, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);
  return Math.max(1, Math.ceil((target.getTime() - now.getTime()) / 60000));
}

function normalizeTimes(timesText) {
  return String(timesText || "")
    .split(/[，,\s]+/)
    .map(x => x.trim())
    .filter(Boolean)
    .filter(x => /^(\d{1,2}):(\d{2})$/.test(x));
}

async function notify(title, message) {
  try {
    await chrome.notifications.create({ type: "basic", title, message });
  } catch (_) {}
}

function isChatGPTUrl(url = "") {
  return /chatgpt\.com|chat\.openai\.com/i.test(url);
}

function isTikTokUrl(url = "") {
  return /ads\.tiktok\.com|seller\.tiktokglobalshop\.com|tiktok/i.test(url);
}

function isLikelyGmvMaxPage(tab) {
  const url = tab?.url || "";
  const title = tab?.title || "";
  return isTikTokUrl(url) && (/gmv[-_/]?max/i.test(url) || /GMV\s*Max/i.test(title) || /gmv-max/i.test(url));
}

async function findTikTokGmvTab() {
  const active = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (active && isLikelyGmvMaxPage(active)) return active;

  const tabs = await chrome.tabs.query({});
  const gmv = tabs.find(t => isLikelyGmvMaxPage(t));
  if (gmv) return gmv;

  const candidates = tabs.filter(t => t.url && isTikTokUrl(t.url));
  return candidates[0] || null;
}

async function findChatGPTTab() {
  const active = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (active && isChatGPTUrl(active.url || "")) return active;
  const tabs = await chrome.tabs.query({});
  const chats = tabs.filter(t => t.url && isChatGPTUrl(t.url));
  if (!chats.length) return null;
  const currentWindow = chats.find(t => active && t.windowId === active.windowId);
  return currentWindow || chats[0];
}

async function waitForTabComplete(tabId, timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return true;
    } catch (_) { return false; }
    await wait(500);
  }
  return false;
}

async function ensureContent(tabId, pingType = "PING_V10") {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: pingType });
    if (pong && pong.ok && pong.version === VERSION) return;
  } catch (_) {}
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  await wait(600);
}

async function captureScreenshotForTab(tab) {
  try {
    if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
    await chrome.tabs.update(tab.id, { active: true });
    await wait(900);
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    return dataUrl;
  } catch (e) {
    return null;
  }
}

async function sendSnapshotLocal(snapshot, screenshotDataUrl, meta = {}) {
  const resp = await localFetch(`/snapshot`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ snapshot, screenshotDataUrl, meta })
  });
  return await readJsonResponse(resp);
}

function buildFallbackMessage(saved) {
  const s = saved.summary || {};
  const ch = saved.change || {};
  return [
    "这是我的 TikTok GMV Max 广告管家 v1.5 数据，请帮我复核哪些计划该保留、关停、降预算、加预算，以及新品冷启动怎么安排。",
    "",
    "【总览】",
    `广告计划数：${s.totalCampaigns || saved.campaign_count || 0}`,
    `生效计划：${s.activeCount || 0}，暂停计划：${s.pausedCount || 0}`,
    `总消耗：${s.totalSpendUSD || 0} USD`,
    `总收入：${s.totalRevenueUSD || 0} USD`,
    `SKU订单数：${s.totalOrders || 0}`,
    `整体ROI：${s.overallROI || 0}`,
    "",
    "【相比上次变化】",
    ch.has_previous ? `消耗 ${ch.deltaSpendUSD || 0} USD，订单 ${ch.deltaOrders || 0}，收入 ${ch.deltaRevenueUSD || 0} USD` : "第一次采集，暂无上次数据。",
    "",
    `本地文件夹：${saved.saved_dir || ""}`,
    "完整 CSV 在 gmv_campaigns.csv，截图在 screenshot.png。"
  ].join("\n");
}


function recomputeGmvSummary(campaigns, source = "all_pages") {
  const n = (v) => Number(v || 0) || 0;
  const totalSpendUSD = campaigns.reduce((s, x) => s + n(x.costUSD), 0);
  const totalRevenueUSD = campaigns.reduce((s, x) => s + n(x.revenueUSD), 0);
  const totalOrders = campaigns.reduce((s, x) => s + n(x.skuOrders), 0);
  const activeCount = campaigns.filter(x => x.status === "已生效").length;
  const pausedCount = campaigns.filter(x => x.status === "已暂停").length;
  const visibleBudgetUSD = campaigns.reduce((s, x) => s + n(x.dailyBudgetUSD), 0);
  return {
    totalCampaigns: campaigns.length,
    activeCount,
    pausedCount,
    totalSpendUSD: Math.round(totalSpendUSD * 100) / 100,
    totalRevenueUSD: Math.round(totalRevenueUSD * 100) / 100,
    totalOrders,
    overallROI: totalSpendUSD > 0 ? Math.round((totalRevenueUSD / totalSpendUSD) * 100) / 100 : 0,
    visibleBudgetUSD: Math.round(visibleBudgetUSD * 100) / 100,
    source
  };
}

function mergeCampaignsUnique(target, incoming, seen) {
  for (const c of incoming || []) {
    const key = (c.campaignName || '').trim() || JSON.stringify([c.status, c.costUSD, c.skuOrders, c.revenueUSD, c.roi]);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    target.push({ ...c, index: target.length + 1 });
  }
}

async function collectSnapshotAllPages(tab, options = {}) {
  await ensureContent(tab.id, "PING_V10");
  const firstRes = await chrome.tabs.sendMessage(tab.id, { type: "GET_SNAPSHOT_V10" });
  if (!firstRes || !firstRes.ok) throw new Error((firstRes && firstRes.error) || "读取 GMV Max 页面失败");

  if (!options.autoPaginate) return firstRes.snapshot;

  const maxPages = Math.max(1, Math.min(20, Number(options.maxPages || 10)));
  const pageWaitMs = Math.max(1000, Number(options.pageWaitMs || 6000));
  const allCampaigns = [];
  const seen = new Set();
  const pages = [];
  let snapshot = firstRes.snapshot;
  let previousSig = "";

  for (let page = 1; page <= maxPages; page++) {
    const campaigns = snapshot?.gmv?.campaigns || [];
    mergeCampaignsUnique(allCampaigns, campaigns, seen);
    const names = campaigns.map(c => c.campaignName || '').join('|');
    const sig = `${campaigns.length}:${names}`;
    pages.push({
      page,
      count: campaigns.length,
      totalMerged: allCampaigns.length,
      pagination: snapshot.pagination || {},
      title: snapshot.title,
      url: snapshot.url
    });

    if (page >= maxPages) break;
    const pag = snapshot.pagination || {};
    if (!pag.hasNext) break;
    if (page > 1 && sig === previousSig) break;
    previousSig = sig;

    const click = await chrome.tabs.sendMessage(tab.id, { type: "CLICK_NEXT_PAGE_V10" });
    if (!click || !click.ok) break;
    await wait(pageWaitMs);
    const nextRes = await chrome.tabs.sendMessage(tab.id, { type: "GET_SNAPSHOT_V10" });
    if (!nextRes || !nextRes.ok) break;
    snapshot = nextRes.snapshot;
  }

  const merged = { ...snapshot };
  merged.capturedAt = new Date().toISOString();
  merged.autoPaginated = true;
  merged.pagesRead = pages.length;
  merged.pageSnapshots = pages;
  merged.gmv = merged.gmv || {};
  merged.gmv.campaigns = allCampaigns;
  merged.gmv.items = allCampaigns;
  merged.gmv.summary = { ...recomputeGmvSummary(allCampaigns), autoPaginated: true, pagesRead: pages.length, maxPages };
  return merged;
}

async function autoCaptureNow(reason = "manual", extraMeta = {}) {
  const startedAt = new Date().toISOString();
  const tab = await findTikTokGmvTab();
  if (!tab || !tab.id) throw new Error("找不到 TikTok / GMV Max 标签页。请先打开 TikTok GMV Max 页面。 ");

  const refreshBeforeCapture = !!extraMeta.refreshBeforeCapture;
  if (refreshBeforeCapture) {
    await chrome.windows.update(tab.windowId, { focused: true });
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.tabs.reload(tab.id, { bypassCache: false });
    await waitForTabComplete(tab.id, 60000);
    await wait(Number(extraMeta.waitAfterRefreshMs || 120000));
  }

  const snapshot = await collectSnapshotAllPages(tab, {
    autoPaginate: extraMeta.autoPaginate !== false,
    maxPages: Number(extraMeta.maxPages || 10),
    pageWaitMs: Number(extraMeta.pageWaitMs || 6000)
  });

  const screenshot = await captureScreenshotForTab(tab);
  const saved = await sendSnapshotLocal(snapshot, screenshot, {
    auto: true,
    reason,
    startedAt,
    tabId: tab.id,
    tabUrl: tab.url,
    tabTitle: tab.title,
    extensionVersion: VERSION,
    ...extraMeta
  });

  const result = {
    ok: true,
    version: VERSION,
    reason,
    capturedAt: new Date().toISOString(),
    tab: { id: tab.id, title: tab.title, url: tab.url },
    screenshotSaved: Boolean(screenshot),
    saved
  };
  await chrome.storage.local.set({
    lastAutoResult: result,
    latestChatGPTMessage: saved.chatgpt_message_text || buildFallbackMessage(saved)
  });
  return result;
}



async function startBackgroundCaptureJob(reason = "manual", extraMeta = {}) {
  const jobId = `job_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  const tab = await findTikTokGmvTab();
  if (!tab || !tab.id) throw new Error("找不到 TikTok / GMV Max 标签页。请先打开 TikTok GMV Max 页面。");

  const waitAfterRefreshMs = Number(extraMeta.waitAfterRefreshMs || 120000);
  const refreshBeforeCapture = extraMeta.refreshBeforeCapture !== false;
  const job = {
    id: jobId,
    version: VERSION,
    reason,
    state: refreshBeforeCapture ? "waiting_after_refresh" : "capturing",
    createdAt: new Date().toISOString(),
    tabId: tab.id,
    windowId: tab.windowId,
    tabUrl: tab.url,
    tabTitle: tab.title,
    waitAfterRefreshMs,
    extraMeta: { ...extraMeta, refreshBeforeCapture: false }
  };

  if (refreshBeforeCapture) {
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
    try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
    await chrome.storage.local.set({
      currentBackgroundJob: job,
      lastAutoResult: { ok: true, version: VERSION, job_started: true, job, message: "已刷新网页，后台等待后再采集。弹窗可以关闭，本地管家不会因此断开。" }
    });
    await chrome.tabs.reload(tab.id, { bypassCache: false });
    const delayMinutes = Math.max(1, Math.ceil(waitAfterRefreshMs / 60000));
    await chrome.alarms.create(`${JOB_ALARM_PREFIX}${jobId}`, { delayInMinutes: delayMinutes });
    await notify("GMV Max 后台任务已启动", `已刷新页面，后台等待约 ${delayMinutes} 分钟后采集。插件弹窗可以关闭。`);
    return { ok: true, version: VERSION, job_started: true, job, delayMinutes, message: "已刷新网页，后台等待后再采集。插件弹窗可以关闭。" };
  }

  await chrome.storage.local.set({ currentBackgroundJob: job });
  return await runBackgroundCaptureJob(job);
}

async function runBackgroundCaptureJob(job) {
  const currentJob = { ...job, state: "capturing", captureStartedAt: new Date().toISOString() };
  await chrome.storage.local.set({ currentBackgroundJob: currentJob });
  let tab = null;
  try { tab = await chrome.tabs.get(job.tabId); } catch (_) {}
  if (!tab || !tab.id) tab = await findTikTokGmvTab();
  if (!tab || !tab.id) throw new Error("后台等待结束后找不到 TikTok GMV Max 标签页。请保持 GMV Max 页面打开。");

  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
  await waitForTabComplete(tab.id, 60000);
  await wait(3000);

  const result = await autoCaptureNow(job.reason || "background_job", {
    ...(job.extraMeta || {}),
    refreshBeforeCapture: false,
    jobId: job.id,
    backgroundJob: true
  });

  const mode = (job.extraMeta && (job.extraMeta.chatgptMode || (job.extraMeta.chatgptRequested ? (job.extraMeta.chatgptAutoClickSend ? "send" : "paste") : "none"))) || "none";
  const forceSend = !!(job.extraMeta && job.extraMeta.forceSend);
  const shouldSend = forceSend || result.saved?.should_send !== false;
  let chatgpt = null;
  if (shouldSend && (mode === "paste" || mode === "send")) {
    const msg = result.saved?.chatgpt_message_text || buildFallbackMessage(result.saved || {});
    chatgpt = await openChatGPTWithText(msg, { autoClickSend: mode === "send" });
  }

  const finalResult = {
    ...result,
    job_completed: true,
    job: { ...currentJob, state: "completed", completedAt: new Date().toISOString() },
    chatgpt
  };
  await chrome.storage.local.set({
    lastAutoResult: finalResult,
    currentBackgroundJob: null,
    latestChatGPTMessage: result.saved?.chatgpt_message_text || buildFallbackMessage(result.saved || {})
  });
  await notify("GMV Max 后台采集完成", `${result.saved?.should_send === false ? "数据无变化，未发送" : "采集完成"}；计划 ${result.saved?.campaign_count || result.saved?.summary?.totalCampaigns || 0} 条。`);
  return finalResult;
}

async function openChatGPTWithText(text, options = {}) {
  const autoClickSend = !!options.autoClickSend;
  let tab = await findChatGPTTab();
  if (!tab) {
    tab = await chrome.tabs.create({ url: "https://chatgpt.com/", active: true });
    await wait(5000);
  } else {
    await chrome.windows.update(tab.windowId, { focused: true });
    await chrome.tabs.update(tab.id, { active: true });
    await wait(1200);
  }

  await ensureContent(tab.id, "PING_CHATGPT_V10");
  const res = await chrome.tabs.sendMessage(tab.id, {
    type: "SEND_TO_CHATGPT_V10",
    text,
    autoClickSend
  });
  if (!res || !res.ok) throw new Error((res && res.error) || "写入 ChatGPT 失败");
  const result = { ok: true, version: VERSION, tab: { id: tab.id, title: tab.title, url: tab.url }, autoClickSend, result: res };
  await chrome.storage.local.set({ lastChatGPTSendResult: result });
  return result;
}

async function captureAndSendToChatGPT(autoClickSend = false, forceSend = true) {
  return await startBackgroundCaptureJob(autoClickSend ? "manual_capture_and_send" : "manual_capture_and_paste", {
    chatgptRequested: true,
    chatgptMode: autoClickSend ? "send" : "paste",
    chatgptAutoClickSend: autoClickSend,
    forceSend,
    noDuplicate: false,
    refreshBeforeCapture: true,
    waitAfterRefreshMs: 120000,
    autoPaginate: true,
    maxPages: 10,
    pageWaitMs: 6000
  });
}

async function openLatestMessageInChatGPT(autoClickSend = false) {
  let data = await chrome.storage.local.get(["latestChatGPTMessage"]);
  let text = data.latestChatGPTMessage;
  if (!text) {
    const resp = await localFetch(`/latest-message`);
    const json = await readJsonResponse(resp);
    text = json.chatgpt_message_text;
  }
  if (!text) throw new Error("没有找到可发送的最新消息，请先采集一次 GMV Max 数据。 ");
  const sendResult = await openChatGPTWithText(text, { autoClickSend });
  return { ok: true, version: VERSION, chatgpt: sendResult };
}



async function findTikTokTabAny() {
  const active = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (active && isTikTokUrl(active.url || '')) return active;
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => t.url && isTikTokUrl(t.url)) || null;
}

async function saveCurrentCreativeUrl() {
  const active = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!active || !active.url || !isTikTokUrl(active.url)) throw new Error('请先打开 TikTok 素材/Creative 页面，再保存当前素材页地址。');
  await chrome.storage.local.set({ savedCreativeUrl: active.url, savedCreativeTitle: active.title || '', savedCreativeAt: new Date().toISOString() });
  return { ok: true, version: VERSION, savedCreativeUrl: active.url, title: active.title || '' };
}

async function openSavedCreativeTab(savedUrl) {
  if (!savedUrl) throw new Error('还没有保存素材页地址。请先打开素材页面，点“保存当前素材页地址”。');
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(t => (t.url || '').split('#')[0] === savedUrl.split('#')[0]);
  if (tab) {
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
    tab = await chrome.tabs.update(tab.id, { active: true, url: savedUrl });
  } else {
    tab = await chrome.tabs.create({ url: savedUrl, active: true });
  }
  return tab;
}

async function collectCreativeSnapshotFromTab(tab) {
  await ensureContent(tab.id, 'PING_V10');
  const res = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CREATIVE_FULL_V121', options: { scrollWaitMs: 900 } });
  if (!res || !res.ok) throw new Error((res && res.error) || '读取素材页面失败');
  const snapshot = res.snapshot || {};
  snapshot.creative = res.creative || snapshot.creative || {};
  snapshot.gmv = null; // 素材诊断不覆盖 GMV 判断逻辑
  snapshot.pageKind = 'creative_diagnosis';
  snapshot.isCreativeImportTest = true;
  return snapshot;
}

async function collectAndSendCreativeJob(job) {
  const currentJob = { ...job, state: "capturing", captureStartedAt: new Date().toISOString() };
  await chrome.storage.local.set({ currentCreativeImportJob: currentJob });

  let tab = null;
  try { tab = await chrome.tabs.get(job.tabId); } catch (_) {}
  if (!tab || !tab.id) {
    if (job.savedCreativeUrl) tab = await openSavedCreativeTab(job.savedCreativeUrl);
    else tab = await findTikTokTabAny();
  }
  if (!tab || !tab.id) throw new Error('后台等待结束后找不到素材页面。请重新保存素材页地址。');

  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
  await waitForTabComplete(tab.id, 60000);
  await wait(2500);

  let freshTab = tab;
  try { freshTab = await chrome.tabs.get(tab.id); } catch (_) {}
  const snapshot = await collectCreativeSnapshotFromTab(freshTab);
  const screenshot = await captureScreenshotForTab(freshTab);
  const saved = await sendSnapshotLocal(snapshot, screenshot, {
    auto: false,
    reason: 'creative_diagnosis',
    pageType: 'creative',
    forceSend: job.forceSend !== false,
    noDuplicate: job.noDuplicate !== false,
    sendOnlyImportant: !!job.sendOnlyImportant,
    scheduledCreative: !!job.scheduledCreative,
    waitAfterOpenMs: job.waitAfterOpenMs,
    savedCreativeUrl: job.savedCreativeUrl || '',
    extensionVersion: VERSION,
    backgroundCreativeJob: true,
    jobId: job.id
  });

  let chatgpt = null;
  const shouldSend = job.forceSend !== false || saved.should_send !== false;
  if (shouldSend && (job.chatgptMode === 'paste' || job.chatgptMode === 'send')) {
    const msg = saved.chatgpt_message_text || '【素材数据诊断】素材数据已采集，但本地管家没有生成消息。';
    chatgpt = await openChatGPTWithText(msg, { autoClickSend: job.chatgptMode === 'send' });
  }

  const result = {
    ok: true,
    version: VERSION,
    type: 'creative_diagnosis',
    job_completed: true,
    job: { ...currentJob, state: 'completed', completedAt: new Date().toISOString() },
    tab: { id: freshTab.id, title: freshTab.title, url: freshTab.url },
    saved,
    chatgpt
  };
  await chrome.storage.local.set({
    lastCreativeImportResult: result,
    currentCreativeImportJob: null,
    latestChatGPTMessage: saved.chatgpt_message_text || ''
  });
  await notify('素材诊断完成', shouldSend ? (job.chatgptMode === 'send' ? '已采集素材数据，并尝试发送到 ChatGPT。' : '已采集素材数据，并填入 ChatGPT。') : '素材数据无重要变化，本次未发送。');
  return result;
}



async function collectAndSendRefreshedCurrentCreativeJob(job) {
  const currentJob = { ...job, state: "refreshing", refreshStartedAt: new Date().toISOString() };
  await chrome.storage.local.set({ currentCreativeImportJob: currentJob });

  let tab = null;
  try { tab = await chrome.tabs.get(job.tabId); } catch (_) {}
  if (!tab || !tab.id) tab = await findTikTokTabAny();
  if (!tab || !tab.id) throw new Error('找不到当前 TikTok 素材页面。请先打开广告计划数据分析 > 创意素材页面。');

  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
  try { await chrome.tabs.reload(tab.id, { bypassCache: true }); } catch (e) { await chrome.tabs.update(tab.id, { url: tab.url }); }
  await waitForTabComplete(tab.id, 90000);

  const waitingJob = { ...currentJob, state: "waiting_after_refresh", refreshedAt: new Date().toISOString() };
  await chrome.storage.local.set({ currentCreativeImportJob: waitingJob });
  await wait(job.waitAfterRefreshMs || 30000);

  let freshTab = await chrome.tabs.get(tab.id);
  try { await chrome.tabs.update(freshTab.id, { active: true }); } catch (_) {}
  await waitForTabComplete(freshTab.id, 30000);
  await wait(1500);

  const snapshot = await collectCreativeSnapshotFromTab(freshTab);
  snapshot.refreshedCurrentCreative = true;
  const screenshot = await captureScreenshotForTab(freshTab);
  const saved = await sendSnapshotLocal(snapshot, screenshot, {
    auto: false,
    reason: 'creative_diagnosis_refresh_current',
    pageType: 'creative',
    forceSend: job.forceSend !== false,
    noDuplicate: job.noDuplicate !== false,
    sendOnlyImportant: !!job.sendOnlyImportant,
    scheduledCreative: !!job.scheduledCreative,
    waitAfterRefreshMs: job.waitAfterRefreshMs,
    savedCreativeUrl: freshTab.url || '',
    extensionVersion: VERSION,
    refreshedCurrentCreative: true,
    jobId: job.id
  });

  let chatgpt = null;
  const shouldSend = job.forceSend !== false || saved.should_send !== false;
  if (shouldSend && (job.chatgptMode === 'paste' || job.chatgptMode === 'send')) {
    const msg = saved.chatgpt_message_text || '【素材诊断】当前素材页已刷新并采集，但本地管家没有生成消息。';
    chatgpt = await openChatGPTWithText(msg, { autoClickSend: job.chatgptMode === 'send' });
  }

  const result = {
    ok: true,
    version: VERSION,
    type: 'creative_refresh_current',
    job_completed: true,
    job: { ...waitingJob, state: 'completed', completedAt: new Date().toISOString() },
    tab: { id: freshTab.id, title: freshTab.title, url: freshTab.url },
    saved,
    chatgpt
  };
  await chrome.storage.local.set({
    lastCreativeImportResult: result,
    currentCreativeImportJob: null,
    latestChatGPTMessage: saved.chatgpt_message_text || ''
  });
  await notify('素材刷新诊断完成', shouldSend ? (job.chatgptMode === 'send' ? '已刷新素材页、采集数据，并尝试发送到 ChatGPT。' : '已刷新素材页、采集数据，并填入 ChatGPT。') : '素材数据无重要变化，本次未发送。');
  return result;
}

async function startRefreshCurrentCreativeJob(options = {}) {
  const waitAfterRefreshMs = Math.max(5000, Number(options.waitAfterRefreshMs || 30000));
  const chatgptMode = options.chatgptMode || 'paste';
  const tab = await findTikTokTabAny();
  if (!tab || !tab.id) throw new Error('找不到 TikTok 素材页面。请先打开广告计划数据分析 > 创意素材页面。');
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}

  const jobId = `creative_refresh_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  const job = {
    id: jobId,
    version: VERSION,
    type: 'creative_refresh_current',
    state: 'queued_refresh',
    createdAt: new Date().toISOString(),
    tabId: tab.id,
    windowId: tab.windowId,
    tabUrl: tab.url,
    tabTitle: tab.title,
    waitAfterRefreshMs,
    chatgptMode,
    noDuplicate: options.noDuplicate !== false,
    sendOnlyImportant: !!options.sendOnlyImportant,
    forceSend: options.forceSend !== false,
    scheduledCreative: !!options.scheduledCreative
  };
  await chrome.storage.local.set({
    currentCreativeImportJob: job,
    lastCreativeImportResult: { ok: true, version: VERSION, job_started: true, job, message: '当前素材页刷新任务已启动，后台刷新后等待再诊断。弹窗可以关闭。' }
  });
  // 立即用 alarm 进入后台执行，避免弹窗关闭导致任务丢失。
  await chrome.alarms.create(`${CREATIVE_REFRESH_JOB_ALARM_PREFIX}${jobId}`, { delayInMinutes: 0.01 });
  await notify('素材刷新诊断任务已启动', `将刷新当前素材页，等待约 ${Math.round(waitAfterRefreshMs / 1000)} 秒后采集。`);
  return { ok: true, version: VERSION, type: 'creative_refresh_current', job_started: true, job, delaySeconds: Math.round(waitAfterRefreshMs / 1000), message: '当前素材页刷新任务已启动，后台刷新后等待再诊断。弹窗可以关闭。' };
}

async function collectAndSendCurrentCreativeNow(options = {}) {
  const chatgptMode = options.chatgptMode || 'paste'; // none | paste | send
  const tab = await findTikTokTabAny();
  if (!tab || !tab.id) throw new Error('找不到 TikTok 素材页面。请先打开广告计划数据分析 > 创意素材页面。');
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
  await waitForTabComplete(tab.id, 30000);
  await wait(1000);
  const freshTab = await chrome.tabs.get(tab.id);
  const snapshot = await collectCreativeSnapshotFromTab(freshTab);
  snapshot.noRefreshCurrentCreative = true;
  const screenshot = await captureScreenshotForTab(freshTab);
  const saved = await sendSnapshotLocal(snapshot, screenshot, {
    auto: false,
    reason: 'creative_diagnosis_current_no_refresh',
    pageType: 'creative',
    forceSend: true,
    noDuplicate: false,
    savedCreativeUrl: freshTab.url || '',
    extensionVersion: VERSION,
    currentPageNoRefresh: true
  });
  let chatgpt = null;
  if (chatgptMode === 'paste' || chatgptMode === 'send') {
    const msg = saved.chatgpt_message_text || '【素材诊断】当前素材页已采集，但本地管家没有生成消息。';
    chatgpt = await openChatGPTWithText(msg, { autoClickSend: chatgptMode === 'send' });
  }
  const result = {
    ok: true,
    version: VERSION,
    type: 'creative_current_no_refresh',
    tab: { id: freshTab.id, title: freshTab.title, url: freshTab.url },
    saved,
    chatgpt
  };
  await chrome.storage.local.set({
    lastCreativeImportResult: result,
    latestChatGPTMessage: saved.chatgpt_message_text || ''
  });
  return result;
}

async function startCreativeImportJob(options = {}) {
  const data = await chrome.storage.local.get(['savedCreativeUrl', 'savedCreativeTitle']);
  const useCurrent = !!options.useCurrent;
  const waitAfterOpenMs = Math.max(5000, Number(options.waitAfterOpenMs || 30000));
  const chatgptMode = options.chatgptMode || 'paste'; // none | paste | send
  let tab = null;

  if (useCurrent) {
    tab = await findTikTokTabAny();
    if (!tab) throw new Error('找不到 TikTok 素材页面。请先打开素材页面，或保存素材页地址。');
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
    try { await chrome.tabs.update(tab.id, { active: true }); } catch (_) {}
  } else {
    tab = await openSavedCreativeTab(data.savedCreativeUrl);
  }

  await waitForTabComplete(tab.id, 60000);
  const jobId = `creative_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  const job = {
    id: jobId,
    version: VERSION,
    type: 'creative_diagnosis',
    state: 'waiting_after_open',
    createdAt: new Date().toISOString(),
    tabId: tab.id,
    windowId: tab.windowId,
    tabUrl: tab.url,
    tabTitle: tab.title,
    waitAfterOpenMs,
    chatgptMode,
    savedCreativeUrl: data.savedCreativeUrl || tab.url || '',
    noDuplicate: options.noDuplicate !== false,
    sendOnlyImportant: !!options.sendOnlyImportant,
    forceSend: options.forceSend !== false,
    scheduledCreative: !!options.scheduledCreative
  };

  await chrome.storage.local.set({
    currentCreativeImportJob: job,
    lastCreativeImportResult: { ok: true, version: VERSION, job_started: true, job, message: '素材页已打开，后台等待后进行诊断。弹窗可以关闭。' }
  });

  const delayMinutes = Math.max(0.5, waitAfterOpenMs / 60000);
  await chrome.alarms.create(`${CREATIVE_JOB_ALARM_PREFIX}${jobId}`, { delayInMinutes: delayMinutes });
  await notify('素材诊断任务已启动', `已打开素材页，后台等待约 ${Math.round(delayMinutes * 60)} 秒后采集。`);
  return { ok: true, version: VERSION, type: 'creative_diagnosis', job_started: true, job, delaySeconds: Math.round(delayMinutes * 60), message: '素材页已打开，后台等待后进行诊断。弹窗可以关闭。' };
}


async function clearCreativeScheduleAlarms() {
  const alarms = await chrome.alarms.getAll();
  await Promise.all(alarms.filter(a => a.name.startsWith(CREATIVE_SCHEDULE_ALARM_PREFIX)).map(a => chrome.alarms.clear(a.name)));
}

async function setCreativeSchedule(config = {}) {
  const times = normalizeTimes(config.timesText || config.times || "");
  const intervalMinutes = Number(config.intervalMinutes || 0);
  const chatgptMode = config.chatgptMode || "none"; // none | paste | send
  const waitAfterOpenMs = Math.max(5000, Number(config.waitAfterOpenMs || 30000));
  const noDuplicate = config.noDuplicate !== false;
  const sendOnlyImportant = !!config.sendOnlyImportant;
  await clearCreativeScheduleAlarms();
  const created = [];
  if (intervalMinutes && intervalMinutes >= 5) {
    await chrome.alarms.create(`${CREATIVE_SCHEDULE_ALARM_PREFIX}INTERVAL`, { delayInMinutes: 1, periodInMinutes: intervalMinutes });
    created.push({ type: "interval", everyMinutes: intervalMinutes });
  }
  for (const time of times) {
    const delay = getDelayMinutesForTime(time);
    if (delay !== null) {
      await chrome.alarms.create(`${CREATIVE_SCHEDULE_ALARM_PREFIX}${time}`, { delayInMinutes: delay, periodInMinutes: 1440 });
      created.push({ type: "daily", time, delayInMinutes: delay });
    }
  }
  const enabled = created.length > 0;
  const savedConfig = {
    enabled,
    times,
    intervalMinutes: intervalMinutes >= 5 ? intervalMinutes : 0,
    chatgptMode,
    waitAfterOpenMs,
    noDuplicate,
    sendOnlyImportant,
    createdAt: new Date().toISOString(),
    note: "v1.3 素材定时监控：自动打开/刷新已保存素材页，等待后采集，只在素材变化或重要变化时发送。"
  };
  await chrome.storage.local.set({ creativeScheduleConfig: savedConfig });
  return { ok: true, version: VERSION, created, config: savedConfig };
}

async function getCreativeScheduleStatus() {
  const data = await chrome.storage.local.get(["creativeScheduleConfig", "savedCreativeUrl", "lastCreativeImportResult", "currentCreativeImportJob", "latestChatGPTMessage"]);
  const alarms = await chrome.alarms.getAll();
  const creativeAlarms = alarms.filter(a => a.name.startsWith(CREATIVE_SCHEDULE_ALARM_PREFIX)).map(a => ({
    name: a.name,
    scheduledTime: a.scheduledTime ? new Date(a.scheduledTime).toLocaleString() : "",
    periodInMinutes: a.periodInMinutes || null
  }));
  return { ok: true, version: VERSION, config: data.creativeScheduleConfig || null, savedCreativeUrl: data.savedCreativeUrl || "", alarms: creativeAlarms, lastCreativeImportResult: data.lastCreativeImportResult || null, currentCreativeImportJob: data.currentCreativeImportJob || null, hasLatestMessage: Boolean(data.latestChatGPTMessage) };
}

async function clearScheduleAlarms() {
  const alarms = await chrome.alarms.getAll();
  await Promise.all(alarms.filter(a => a.name.startsWith(ALARM_PREFIX)).map(a => chrome.alarms.clear(a.name)));
}

async function setSchedule(config) {
  const times = normalizeTimes(config.timesText || config.times || "");
  const intervalMinutes = Number(config.intervalMinutes || 0);
  const chatgptMode = config.chatgptMode || "none"; // none | paste | send
  const refreshBeforeCapture = config.refreshBeforeCapture !== false;
  const noDuplicate = config.noDuplicate !== false;
  const sendOnlyImportant = !!config.sendOnlyImportant;
  const waitAfterRefreshMs = Number(config.waitAfterRefreshMs || 120000);
  const autoPaginate = config.autoPaginate !== false;
  const maxPages = Math.max(1, Math.min(20, Number(config.maxPages || 10)));
  const pageWaitMs = Math.max(1000, Number(config.pageWaitMs || 6000));
  const activeOnlyMessage = !!config.activeOnlyMessage;
  await clearScheduleAlarms();

  const created = [];
  if (intervalMinutes && intervalMinutes >= 5) {
    await chrome.alarms.create(`${ALARM_PREFIX}INTERVAL`, { delayInMinutes: 1, periodInMinutes: intervalMinutes });
    created.push({ type: "interval", everyMinutes: intervalMinutes });
  }

  for (const time of times) {
    const delay = getDelayMinutesForTime(time);
    if (delay !== null) {
      await chrome.alarms.create(`${ALARM_PREFIX}${time}`, { delayInMinutes: delay, periodInMinutes: 1440 });
      created.push({ type: "daily", time, delayInMinutes: delay });
    }
  }

  const enabled = created.length > 0;
  const savedConfig = {
    enabled,
    times,
    intervalMinutes: intervalMinutes >= 5 ? intervalMinutes : 0,
    chatgptMode,
    refreshBeforeCapture,
    noDuplicate,
    sendOnlyImportant,
    waitAfterRefreshMs,
    autoPaginate,
    maxPages,
    pageWaitMs,
    activeOnlyMessage,
    createdAt: new Date().toISOString(),
    localUrl: LOCAL_URL,
    note: "v1.3 默认：采集前刷新，等待 2 分钟，自动翻页读取全部计划，只在有变化时发送。"
  };
  await chrome.storage.local.set({ scheduleConfig: savedConfig });
  return { ok: true, version: VERSION, created, config: savedConfig };
}

async function getScheduleStatus() {
  const data = await chrome.storage.local.get(["scheduleConfig", "lastAutoResult", "lastChatGPTSendResult", "latestChatGPTMessage", "currentBackgroundJob"]);
  const alarms = await chrome.alarms.getAll();
  const gmvAlarms = alarms.filter(a => a.name.startsWith(ALARM_PREFIX)).map(a => ({
    name: a.name,
    scheduledTime: a.scheduledTime ? new Date(a.scheduledTime).toLocaleString() : "",
    periodInMinutes: a.periodInMinutes || null
  }));
  let localState = null;
  try {
    const resp = await localFetch(`/state`);
    localState = await readJsonResponse(resp);
  } catch (_) {}
  return {
    ok: true,
    version: VERSION,
    config: data.scheduleConfig || null,
    alarms: gmvAlarms,
    lastAutoResult: data.lastAutoResult || null,
    lastChatGPTSendResult: data.lastChatGPTSendResult || null,
    hasLatestMessage: Boolean(data.latestChatGPTMessage),
    currentBackgroundJob: data.currentBackgroundJob || null,
    localState
  };
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  try {
    if (alarm.name.startsWith(CREATIVE_REFRESH_JOB_ALARM_PREFIX)) {
      const data = await chrome.storage.local.get(['currentCreativeImportJob']);
      const job = data.currentCreativeImportJob;
      if (job && job.id && alarm.name.endsWith(job.id)) {
        try { await collectAndSendRefreshedCurrentCreativeJob(job); }
        catch (e) {
          const failed = { ...(job || {}), state: 'failed', error: e.message || String(e), failedAt: new Date().toISOString() };
          await chrome.storage.local.set({ currentCreativeImportJob: null, lastCreativeImportResult: { ok: false, version: VERSION, type: 'creative_refresh_current', job: failed, error: failed.error } });
          await notify('素材刷新诊断失败', failed.error || '未知错误');
        }
      }
      return;
    }
    if (alarm.name.startsWith(CREATIVE_JOB_ALARM_PREFIX)) {
      const data = await chrome.storage.local.get(["currentCreativeImportJob"]);
      const job = data.currentCreativeImportJob;
      if (!job) return;
      return await collectAndSendCreativeJob(job);
    }

    if (alarm.name.startsWith(CREATIVE_SCHEDULE_ALARM_PREFIX)) {
      const data = await chrome.storage.local.get(["creativeScheduleConfig", "savedCreativeUrl"]);
      const cfg = data.creativeScheduleConfig || {};
      if (!data.savedCreativeUrl) throw new Error('素材定时监控未保存素材页地址，请先打开素材页并保存。');
      const start = await startCreativeImportJob({
        chatgptMode: cfg.chatgptMode || 'none',
        waitAfterOpenMs: Number(cfg.waitAfterOpenMs || 30000),
        useCurrent: false,
        noDuplicate: cfg.noDuplicate !== false,
        sendOnlyImportant: !!cfg.sendOnlyImportant,
        forceSend: false,
        scheduledCreative: true
      });
      if (start && start.job_started) await notify('素材定时监控已启动', `已打开/刷新素材页，等待 ${start.delaySeconds || 30} 秒后采集。`);
      return;
    }

    if (alarm.name.startsWith(JOB_ALARM_PREFIX)) {
      const data = await chrome.storage.local.get(["currentBackgroundJob"]);
      const job = data.currentBackgroundJob;
      if (!job) return;
      return await runBackgroundCaptureJob(job);
    }

    if (!alarm.name.startsWith(ALARM_PREFIX)) return;
    const data = await chrome.storage.local.get(["scheduleConfig"]);
    const cfg = data.scheduleConfig || {};
    const mode = cfg.chatgptMode || "none";
    const start = await startBackgroundCaptureJob(alarm.name, {
      chatgptMode: mode,
      refreshBeforeCapture: cfg.refreshBeforeCapture !== false,
      noDuplicate: cfg.noDuplicate !== false,
      sendOnlyImportant: !!cfg.sendOnlyImportant,
      forceSend: false,
      waitAfterRefreshMs: Number(cfg.waitAfterRefreshMs || 120000),
      autoPaginate: cfg.autoPaginate !== false,
      maxPages: Number(cfg.maxPages || 10),
      pageWaitMs: Number(cfg.pageWaitMs || 6000),
      activeOnlyMessage: !!cfg.activeOnlyMessage
    });
    if (start && start.job_started) {
      await notify("GMV Max 定时任务已启动", `已刷新页面，等待 ${start.delayMinutes || 2} 分钟后后台采集。`);
    }
  } catch (e) {
    const err = { ok: false, version: VERSION, capturedAt: new Date().toISOString(), alarm: alarm.name, error: e.message || String(e) };
    if (alarm.name && alarm.name.startsWith(CREATIVE_JOB_ALARM_PREFIX)) {
      await chrome.storage.local.set({ lastCreativeImportResult: err, currentCreativeImportJob: null });
      await notify("素材诊断失败", err.error.slice(0, 120));
    } else {
      await chrome.storage.local.set({ lastAutoResult: err, currentBackgroundJob: null });
      await notify("GMV Max 定时采集失败", err.error.slice(0, 120));
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "CAPTURE_SCREENSHOT") {
      const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "png" });
      return { ok: true, dataUrl };
    }
    if (message.type === "AUTO_CAPTURE_NOW_V10") {
      return await startBackgroundCaptureJob("manual_test", {
        forceSend: !!message.forceSend,
        noDuplicate: message.noDuplicate !== false,
        sendOnlyImportant: !!message.sendOnlyImportant,
        refreshBeforeCapture: message.refreshBeforeCapture !== false,
        waitAfterRefreshMs: Number(message.waitAfterRefreshMs || 120000),
        autoPaginate: message.autoPaginate !== false,
        maxPages: Number(message.maxPages || 10),
        pageWaitMs: Number(message.pageWaitMs || 6000),
        activeOnlyMessage: !!message.activeOnlyMessage
      });
    }
    if (message.type === "CAPTURE_AND_CHATGPT_V10") {
      return await captureAndSendToChatGPT(!!message.autoClickSend, message.forceSend !== false);
    }
    if (message.type === "OPEN_LATEST_CHATGPT_V10") {
      return await openLatestMessageInChatGPT(!!message.autoClickSend);
    }
    if (message.type === "SCHEDULE_SET_V10") {
      return await setSchedule(message.config || {});
    }
    if (message.type === "SCHEDULE_DISABLE_V10") {
      await clearScheduleAlarms();
      await chrome.storage.local.set({ scheduleConfig: { enabled: false, disabledAt: new Date().toISOString() } });
      return { ok: true, version: VERSION, disabled: true };
    }
    if (message.type === "SCHEDULE_STATUS_V10") {
      return await getScheduleStatus();
    }

    if (message.type === "SAVE_CREATIVE_URL_V11") {
      return await saveCurrentCreativeUrl();
    }
    if (message.type === "CREATIVE_IMPORT_CHATGPT_V11") {
      return await startCreativeImportJob(message.options || {});
    }
    if (message.type === "CREATIVE_CURRENT_CHATGPT_V121") {
      return await collectAndSendCurrentCreativeNow(message.options || {});
    }
    if (message.type === "CREATIVE_REFRESH_CURRENT_CHATGPT_V122") {
      return await startRefreshCurrentCreativeJob(message.options || {});
    }
    if (message.type === "GET_CREATIVE_STATUS_V11") {
      const data = await chrome.storage.local.get(['savedCreativeUrl','savedCreativeTitle','savedCreativeAt','lastCreativeImportResult','currentCreativeImportJob','lastChatGPTSendResult','latestChatGPTMessage','creativeScheduleConfig']);
      return { ok: true, version: VERSION, ...data };
    }
    if (message.type === "CREATIVE_SCHEDULE_SET_V13") {
      return await setCreativeSchedule(message.config || {});
    }
    if (message.type === "CREATIVE_SCHEDULE_DISABLE_V13") {
      await clearCreativeScheduleAlarms();
      await chrome.storage.local.set({ creativeScheduleConfig: { enabled: false, disabledAt: new Date().toISOString() } });
      return { ok: true, version: VERSION, disabled: true };
    }
    if (message.type === "CREATIVE_SCHEDULE_STATUS_V13") {
      return await getCreativeScheduleStatus();
    }
    return { ok: false, error: "unknown message" };
  })().then(sendResponse).catch(e => sendResponse({ ok: false, version: VERSION, error: e.message || String(e) }));
  return true;
});
